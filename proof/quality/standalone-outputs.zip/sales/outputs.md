## define-icp

**Rep decision today — needs evidence.** Keep the ten-person prospect in discovery. Headcount alone says nothing about whether they scan yard tickets or make a shift tally. The likely user is the person preparing that tally. The buying authority is unknown.

| Proposed check | Evidence the rep can obtain | How to use it |
| --- | --- | --- |
| Site workflow | Ask the person who closes the shift to walk through the most recent tally, from ticket receipt to finished total. | A repeated manual transfer is a possible buying signal. Its absence has no approved exclusion effect. |
| Ticket-to-tally fit | Compare one shareable scanned ticket with the columns or totals the buyer actually needs. | Confirm what the offer can produce. Ask the delivery owner whether an unsupported input or required output would rule the site out. |

The only sources are the owner's undated product description and reported employee count. There are no approved hard gates or evidenced size thresholds. If an illustrative second prospect already has an electronic tally, record that workflow and investigate whether any scanned tickets still sit outside it. Both prospects stay undecided until the owner identifies which conditions would make them decline an otherwise willing customer.

## select-target-market

**Use Thursday for warehouse discovery.** There is enough access to test the idea with two shift managers. Confidence that this should become the first paid segment is low. Neither manager has yet confirmed the workflow, purchasing authority or demand.

| Segment hypothesis | Practical reason to investigate | Evidence needed |
| --- | --- | --- |
| Warehouses where a shift supervisor collects hourly inspection sheets for a weekly review | Two managers are available Thursday. | Ask to see a redacted sheet and the last weekly review. Identify who assembles the CSV, who uses it and who can authorize a two-week pilot. |
| Production sites where a line supervisor collects hourly equipment-check sheets for a weekly review | The same transformation might fit this separate workflow. Access and demand are unknown. | Ask the same questions of a supervisor or weekly reviewer. |

Interview the two warehouse managers separately. Walk through a real week, including what the reviewer did with the data, how long compilation actually took and where the handoff failed, if anywhere. Ask whether they can share a sample, agree the required CSV columns and commit an owner and review date within the two-week window. A warehouse meeting by itself earns a research row. A site using only a monthly report is outside this initial weekly-review segment.

Offer the single pilot to the first site that demonstrates the workflow, can provide usable inputs and wants its reviewer to compare the output with an actual weekly review. Revisit after Thursday's interviews. If neither has that need, keep the slot open. A production site demonstrating those conditions would move ahead of an unverified warehouse lead.

## assemble-prospect-list

**July renewals, using records through May 5.** Filter R7's May 3 export to active accounts due in July, apply company clearance, then join the May 4 employer roster and May 5 person suppression records. Match by account ID and corroborated person. No domain or person ID was supplied.

| Account | Qualification and source | Disposition |
| --- | --- | --- |
| A7 Granary Supply | R7, May 3. Active, July renewal, company cleared. | Keep. One verified purchasing manager. |
| A8 Oriel | R7, May 3. Active, July renewal, company cleared. | Keep the account. The manager opted out in P2, May 5. Exclude that person. |

| Account | Confirmed person and role | Address | Evidence and disposition |
| --- | --- | --- | --- |
| A7 | Drew Corum, purchasing manager | Unavailable | P1 employer roster verified May 4. P2 person record clear as of May 5. No sendable address in the allowed sources. |

A9 Beam is former in R7 and falls outside this renewal list. Coverage is two qualifying accounts, one confirmed unsuppressed role holder out of two requested, one suppressed contact, zero supplied addresses. The sources support a research handoff, with no send queue.

## extract-buyer-insights

**One of two respondents (50%) described re-keying.** Four distinct accounts were mapped, three were asked, and two answered. Neither answering account independently raised the topic in these notes. This sample supports a statement about the answers to this week's question.

| Account / locator | Interview evidence | Coding |
| --- | --- | --- |
| A, re-keying response | “We do it twice.” | Prompted support. Ask which entry is repeated and where. |
| B, re-keying response | “The import handles it.” | Prompted counterexample. The reported workflow uses an import. |
| C, re-keying question | Asked and unanswered. | Missing answer. |
| D, interview log | Never asked. | Outside the question denominator. |

No account reported the cost, urgency, purchase intent or desire to expand. Those remain open.

## triage-sales-replies

| ID / sender | Target and category | Owner and next action | State |
| --- | --- | --- | --- |
| N7 / mailer | North, p@north.example. Temporary delivery delay. “mailbox temporarily unavailable; retry scheduled.” | Delivery owner checks the sending system for the scheduled retry and its outcome before any manual resend. | Retry pending. Final delivery unknown. No human reply to draft. |
| N8 / mailer | North, q@north.example. Permanent failure. “recipient mailbox does not exist; permanent failure.” | Delivery owner removes this address from the active send queue before another touch and requests a verified correction. | Address correction queued. No human reply to draft. |

Three export rows resolve to two distinct delivery notices for two addresses. The second N8 adds no event or failed address. North has one delayed address and one permanent failure, zero human responses and zero evidence of an account-wide opt-out. No queue or CRM changes have been applied.

## review-crm-duplicates

| Coverage | Decision | Evidence and field treatment |
| --- | --- | --- |
| C1 + C2, one candidate pair | Propose keeping C2 (Oct 3), retiring C1 (Oct 1). | Both records carry verified E10 and the same direct email. All other supplied values agree. Preserve C2’s original field values, keep E10 and the email once, and retain the C1-to-C2 crosswalk. No field replacement or association transfer is indicated. |
| C3, C4, two incomplete identities | Retain each record separately and request an identifying source for each. | The distinct CRM IDs locate the records. Blank name, email, phone and upstream ID establish no match between them. |
| C5, one identifiable singleton | Retain unchanged. | Mira Lo has E19 and no supplied matching record. |

Five input IDs reconcile to two investigated in one pair, one identifiable singleton and two incomplete. The proposal has one survivor within the pair and one retiring ID. Four records would remain after application. Recovery support is unknown. Before any authorized application, retain the raw C1 and C2 records and IDs, current association snapshots (reported empty), the field crosswalk and merge decision. No merge has been applied.
