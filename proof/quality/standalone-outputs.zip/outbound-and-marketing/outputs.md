## plan-outbound-test

**Draft for the rep and owner.** Can the rep give each human reply the attention it needs by the end of the next business day? Use the single approved email once. Take the first six accounts in the already deduped list for the pilot and reserve the other six. Save that list before sending. Each account has one contact.

- Each business morning the rep handles open replies first. Just before sending, the compliance owner checks suppression again. Skip newly suppressed accounts, record the reason and leave their slots empty. Record each actual send date.
- Send at most two new accounts that day with an empty queue, one with one reply outstanding, and zero with two or more. This stays below the daily ceiling of three. Replies to earlier sends can still arrive together. If the queue exceeds two, pause entry immediately and record the peak and any missed deadlines.
- Check the inbox each business day. A human reply ends outreach to that account. Log receipt and the rep’s first substantive response; for an opt-out, log completion of suppression as the handling action. Record referrals on the original account. Hard bounces exit, auto-replies are excluded, and there are no reminders.
- Read results five business days after the last send, allowing one further business day to score the final day's replies. Primary measure: human messages handled by deadline / all human messages received in the window that require action. A second question from the same account is a new work item. Report distinct replying accounts separately. Continue handling late replies and flag them separately. Record eligible accounts (12), pilot accounts selected (6), entered/sent, confirmed reached, delivery unknown, bounced, replying accounts, human work items, timely items, peak outstanding and breached deadlines. Report reached as unknown where delivery cannot be established.
- Proposed rule for owner agreement before entry: open the next small batch if at least two human work items arrived, every one was handled on time and the queue stayed at or below two. With zero or one and no breach, the workload evidence is thin; repeat at the same cap. After any late handling or backlog above two, pause and revise capacity before adding accounts.

Illustrative read: six sent, four confirmed reached, one hard bounce and one unknown. Two accounts generated three human work items, all three handled on time, with a peak of two outstanding. That meets the proposed rule. Actual counts may differ.

## draft-outbound-email

**Single first touch, draft for owner review**  
**Subject:** Sample freight claims log

Hi Val,

I saw that you handle freight damage claims. I have a one-page sample claims log with fields for the receipt date and photo reference. May I send it to you?

**Purpose and ask:** Offer a sample for Val’s stated responsibility and get permission to send it.  
**Source check:** V1, buyer directory entry, identifies Val as responsible for freight damage claims. E1, cleared one-page sample claims log, supports the resource and its two named fields.

## review-outbound-copy

**Revise.** Original subject: “Quick favor”. Original body: “We guarantee 40% less rework. Would you like the sample checklist? Or pick a date for a workshop.”

| Location and original | Edit for the owner |
|---|---|
| Opening: “We guarantee 40% less rework.” | Cut. Reinstatement would require evidence defining rework, the comparison, measured group and period, as well as authorization and terms for the forward guarantee. |
| Close: “Would you like the sample checklist? Or pick a date for a workshop.” | Keep one action. The recipient can request a checklist or choose a workshop date. There is no stated priority. |
| Subject: “Quick favor” | Name the surviving offer so the recipient can see what the message concerns. |

**Option A**  
Subject: Sample checklist  
Would you like the sample checklist?

**Option B**  
Subject: Workshop date  
Would you like to pick a date for a workshop?

Each version has one ask. Which can the owner fulfill for this recipient: sending the checklist or arranging the workshop? Both drafts can go to the owner now. The audience, reason for contact, and availability of the chosen offer still need confirmation before sending.

## substantiate-offer

**Internal draft for the owner.** Proposed wording for regional presses, pending approval for the intended public channel:

“Once you provide your approver list, we can configure one approval queue for your press.”

| Claim or term | Record and owner | Scope and decision |
|---|---|---|
| One approval queue can be configured | Private paid invoice from last May documents a one-queue configuration. Current internal delivery lead note confirms one queue is still available. | Supported for this draft. Delivery is complete when one approval queue is configured. Confirm availability again if scope changes. |
| Press provides the approver list | Current delivery lead note conditions availability on receipt of an approver list. | Keep the prerequisite beside the promise. Receipt enables work to begin; no completion date is established. |
| Current price of $650 | Last May’s private invoice records a historical $650 charge. The current delivery lead note says price is pending. | Withhold from proposed copy. Obtain the pricing owner’s current approved price and conditions. |
| Permission for external use | Current internal note says public approval is pending. | Owner must approve the exact proposed wording and channel before publication. Keep the invoice and note private. |

A deadline or guaranteed operating result would require a separate authorized commitment or relevant outcome evidence. Neither is needed for this one-queue offer.

## build-proof-library

**Editable register update for the owner.** Apply these changes against the existing register, keeping R19’s existing fields and using one claim ID for the April pilot.

| ID / version | Status | Exact claim or retained field | Evidence and scope | Permission and placements | Recheck or action |
|---|---|---|---|---|---|
| R19 / existing | Current capability | Retain existing wording verbatim. | Retain existing evidence, scope and metadata. | Retain existing channels and permission terms. | Keep its existing review date or trigger. |
| R07 / revised | Internal only, approval pending | On route C, median review time across ten visits fell from 20 to 17 minutes. | Analyst correction C3 to the same April route C pilot log; median review time in minutes, ten visits. C3 replaces 16 with 17. | No external channel cleared for this version. The earlier website grant was wording-specific. D9 is another placement of the original observation. | Submit revised wording for the intended channels. Record who approves, where and on what terms before releasing it. |
| R07 / prior | Withdrawn from reuse; formerly approved | On route C, median review time across ten visits fell from 20 to 16 minutes. | Original April route C pilot log; ten visits, median review time in minutes. Superseded by C3. D9 repeats the same log. | Original exact wording had website permission; D9 has no deck permission. | Remove original wording from the website and D9. Check other copies for the superseded figure. Keep the former grant and C3 with this record. |

Downstream writers may use R19 within its existing terms. Retire the 16-minute wording from the website and deck, including any circulating copies. Keep the corrected figure internal pending fresh clearance.
