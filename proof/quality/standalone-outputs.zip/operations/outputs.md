## compare-vendor-proposals

The price decision turns on **145 orders per billing month**. At 144 or fewer, A has the lower quoted service charge. At 146 or more, B does. At 145, both cost $490.

| Orders in month | A, section 2 | B, page 1 |
| ---: | ---: | ---: |
| 0–100 | $400 | $490 |
| 144 | $488 | $490 |
| 145 | $490 | $490 |
| 146 | $492 | $490 |
| 200 | $600 | $490 |

For n orders, A costs $400 + $2 × max(n − 100, 0). B costs $490. The tie is $400 + $2 × 45 = $490. Both are cancellable monthly. The stated base charge for one month is $400 for A or $490 for B. The clauses provided do not specify taxes, other mandatory charges or the payment date.

Today, ask the orders owner to pull the last few **monthly** counts. Apply each quote to each individual month, especially if orders spike seasonally. If you need to choose before seeing that data and an uncapped bill is unacceptable, buy B's $490 cap if the vendor confirms it covers all orders and mandatory charges. If starting volume is credibly below 145 and you can switch after the first month, choose A and set a review at 145. Without either a volume basis or a price-cap preference, the threshold is the defensible decision rule.

## design-workflow-automation

**Facilities handoff — draft for operator review.** One accepted new exhibitor registration creates one facilities setup ticket with the show, booth, exhibitor and power request. Please identify the form owner, facilities queue, expected turnaround and who will handle exceptions.

| Source visible on form | Proposed ticket field | Handling |
| --- | --- | --- |
| Show | Show name or mapped show ID | Required. Match to a known show; send unrecognized choices to review. |
| Booth number | Booth identifier | Required text. Preserve leading zeroes and letters. |
| Exhibitor | Exhibitor name | Required label. Preserve spelling; two exhibitors can have the same display name. |
| Power needed | Power request | Recognized yes/no maps directly. Blank or unfamiliar values go to review so a missing answer cannot be mistaken for no power. |

1. Receive an accepted registration and record its source reference. Request one redacted event payload and its redelivery from the form owner. Verify the provider's stable submission ID, event ID (or equivalent), creation/update semantics and field types. A new delivery attempt gets its own log ID. Show, booth and name can change and cannot identify retries reliably.
2. Validate required fields before writing. Proposed business key is form/source plus immutable registration ID. Proposed effect key is the stable creation event ID plus “create facilities ticket”. Ask the ticket admin which unique external reference, atomic create/upsert or idempotency guarantee their platform supports. Concurrent creates must resolve to the same ticket. If that capability or the source identity remains unresolved, give facilities a manual review queue for this pilot.
3. Create the ticket in the authorized facilities queue with a subject such as “Setup – [Show] – booth [Booth]”. Record registration reference, event/effect key, attempt ID, outcome and returned ticket ID. After a timeout, query the ticket system by external reference. Reuse a confirmed receipt. Hold an ambiguous write for the facilities lead. Bound retries on transient errors; invalid fields go to the form owner and an authorization error pauses the route for the platform owner.
4. Keep subsequent edits on the same registration tied to the same ticket. This brief authorizes a creation design only. Queue changed/out-of-order updates for facilities review pending an update policy. Do a dry run with a sample payload and disable unattended writes until the facilities owner verifies the queue, fields and exceptions.

| Isolated acceptance case | Expected observation |
| --- | --- |
| Two valid registrations R1/R2 | Two distinct tickets with correctly mapped booth and power values. |
| Redelivery or two concurrent workers for R1 | One R1 ticket, one durable ticket reference. |
| R1 creation acknowledgment lost | Existing ticket reconciled; unresolved acceptance stays on hold with no second ticket. |
| Power blank or booth missing | Zero destination writes for that submission, one actionable review item. |
| Newer and older edits after R1 creation | Original ticket retained; no second setup ticket or stale overwrite. |

This paper design is ready to review. Platform import and execution are untested.

## diagnose-workflow-failure

Keep the R-18 confirmation. Write down the calendar date of that Friday, around 4 p.m. Central, and the exact donor tracker or view you checked. Keep donor personal details out of a general support request. Hold off on resubmitting while tracker acceptance is unknown.

Send these two read-only requests:

- **Donor intake form owner** — “Please look up confirmation R-18 for [Friday date], about 4 p.m. Central. Did the source record it? If yes, send the recorded timestamp with zone and the stable submission/event reference or delivery receipt. If it has a handoff status, please include that.”
- **Donor tracker owner** — “Please search the full tracker, including queued, archived and filtered records if applicable, for R-18 or its linked source ID. Do you find zero, one, or multiple matching records? Please return the record/receipt ID and status.”

At present the confirmation is observed and the expected tracker entry is absent from your view. The downstream write is **unknown**. If the tracker owner finds one matching entry, verify the view/filter and stop recovery. If several match, hold and have the owner reconcile them. If the source cannot locate R-18, have that owner trace the confirmation issuance. If the source confirms R-18 and the tracker owner confirms zero after checking pending writes and the expected processing window, ask the workflow owner to trace that one event, compare one successful neighboring submission, and identify the first step with different inputs, outputs or receipt.

If the tracker write alone is confirmed missing, the approved owner can retry that write once under R-18's stable key, skipping any completed side effects. Stop on an ambiguous receipt or a duplicate. Verify exactly one matching donor record after recovery. Cause and recovery are unverified until the owners return those observations.

## standardize-task-instructions

**Monthly return log, provisional draft 1.** At monthly preparation, take the return envelopes for the period. For each, read the order number and date physically stamped on that envelope. Record one row with columns **Order number | Stamped date**, preserving the source order identifier and legible stamp date. Review each completed row against its envelope. Hand the completed rows to Marta in Billing. The described prior run supports these fields and recipient.

When a stamp is absent or unreadable, keep the envelope identifiable and list its order number and the exception for owner review. Never substitute the day you opened it. If the order number is missing or ambiguous, queue that envelope for identification. Continue preparing legible, complete rows. Holding an unstamped envelope was one operator's prior action. Marta or the process owner must decide whether to (a) withhold the row pending a corrected date or (b) send it to Billing with a blank date and an explicit exception. Confirm who keeps custody and tracks resolution. Until that decision, keep the disputed row separate from the completed batch.

**Invocation for a new operator.** “Prepare this month's return log from these envelopes. Give Marta the ready rows and show me which envelopes need a decision, why, and whose decision is needed.”

**Proposed sample and checks for the owner.** These order numbers and dates are invented fixture values. The prior run had no accepted sample output.

| Supplied envelope | Expected ready rows | Expected exception |
| --- | --- | --- |
| RT-01, legible Nov 03 stamp | RT-01 / Nov 03 | None |
| RT-02, no stamp | None pending owner decision | RT-02 / stamp missing / confirm Billing handling |
| RT-03 and RT-04, both legibly stamped Nov 04 | Two rows, one per envelope with its own order number | None |
| Unreadable order number, Nov 05 stamp | None | Retain envelope reference and request order identification |

Desktop walkthrough of draft 1: the described legible envelope can produce one complete row; the unstamped one produces a named exception. Actual order identifiers and dates from that run were unavailable. These are proposed expected outputs. Owner acceptance and a fresh-operator run remain outstanding.

## improve-skill

Save the exact current line as **invoice instructions, baseline 2026-11-23**. The revision that generated the historical result is unknown. You reported it included a paid item. The current text permits any status and doesn't define how to select “latest.”

Replace that line in your saved instructions with this candidate:

> For each supplier requested, use only invoices explicitly marked unpaid. Exclude paid, sent, blank and ambiguous statuses. From that supplier's eligible invoices select the one with the most recent invoice date, regardless of source row order, and return the supplier and the selected invoice total. If none qualifies, report “no explicitly unpaid invoice.” Where a missing date or conflicting records prevent choosing one invoice, or different invoices tie for latest date, identify the ambiguity and ask which to use.

Name this copy **invoice instructions, unpaid-by-date candidate 1**. Keep the baseline available until checks pass.

| Check | Fixture | Expected under candidate |
| --- | --- | --- |
| Reported failure | Mica Ltd, totals 40 sent, 55 paid, 72 unpaid | Mica Ltd — 72. Only one invoice is eligible. |
| Different dates and misleading row order | Birch: unpaid 80 dated Nov 16, paid 100 dated Nov 20, unpaid 50 dated Nov 10 listed last | Birch — 80. |
| Simple passing behavior to preserve | Elm: one dated invoice for 12, marked unpaid | Elm — 12. |
| No eligible records | Oak: 19 sent, 23 paid | Oak — no explicitly unpaid invoice. |

These are expected answers from a desk review. Neither instruction copy was executed here. As the sole owner, you can open a fresh chat with each copy, give each the same fixture **without the answer column**, and save its actual outputs beside the two versions. Adopt the candidate after confirming all rows and verify the active version on a fresh run. Until then it is an unverified candidate.
