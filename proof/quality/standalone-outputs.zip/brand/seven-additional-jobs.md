## 1. Intro for a band director

“If your school band has a broken brass instrument, our van can pick it up on Thursday and take it to our workshop for repair.”

The owner’s operating description establishes weekly collection and workshop repair. The reason directors choose pickup is provisional. Ask one director, “What did you do the last time a brass instrument broke, and what would have made a Thursday pickup worthwhile?”

## 2. Rule for a support writer

Proposed rule for pump-support email, drawn from the one approved message. When asking for a part identifier, tell the customer exactly where to find it and explain who checks fit before the quote.

Illustrative edit: “Send the pump details for a price.” → “Please send the serial number on the pump label. Before we quote, Mei will check which gasket fits.” An independent test against another approved email is pending.

## 3. Standards for the next speaker slide

| Element | Placement on the next slide | Evidence |
| --- | --- | --- |
| Speaker name | Put it at the top left and make it the largest line. | Owner’s description of the approved slide |
| Topic | Set it below the name in smaller type. | Same description |
| Affiliation | Place it at the bottom. | Same description |

For a long name or topic, try wrapping the text and preview at presentation size. Check that the name still reads first and the affiliation stays clear. This is a proposed fit check. Exact fonts, sizes, colors and offsets remain open until a slide or capture is available.

## 4. Logo for a navy partner slide

Select `v4/firefly-white.svg`. Its entry in the supplied manifest clears the white variant for public navy slides. `v5/firefly-cyan.svg` is an unreleased experiment. Ask the asset owner for the exact v4 file. In the working deck, leave the logo space empty until it arrives. The file, its SVG contents and its visibility at final size remain unverified.

## 5. Estimate landing page

**Proposed page copy, in placement order**

Request an estimate

Email the measurements. Our fitter will send the estimate once she has reviewed them.

**Email your measurements**

| Placement | Before | Fix and release decision |
| --- | --- | --- |
| Heading | “Get your estimate now” fails. “Now” promises a result before review. | “Request an estimate” is ready against the supplied process. |
| Instructions | Pass. The customer emails measurements and the fitter reviews them before sending the estimate. | Keep verbatim. |
| Button | “Download estimate” fails. It offers a document before the fitter has reviewed anything. | Hold the current button. Release “Email your measurements” once a click is verified to open an email addressed to the fitter’s intake mailbox. If it opens another step, label that step. |

The button destination and visual presentation were unavailable. Broader voice fit remains unknown without an approved comparator.

## 6. Public directory listing

Mica repairs brass instruments for school bands.

## 7. Website help and confirmation email

Both first drafts adapt the single approved support email. Its sequence is fixed: the customer emails a board photo, then a technician replies with a diagnosis.

| Placement and reader’s question | Proposed copy | Editing check |
| --- | --- | --- |
| Website help, “What should I send?” | “Email a photo of the board to the address shown here. A technician will reply with a diagnosis.” | Put the text beside the embedded address. The owner supplied its placement. Check the displayed address in the page before release. |
| Confirmation email, “Did my photo arrive?” | Subject: “We received your board photo” · Body: “A technician will reply with a diagnosis.” | Send only after the photo arrives. The reader has already completed the email step. |
