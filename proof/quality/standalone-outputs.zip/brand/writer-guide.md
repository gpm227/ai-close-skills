# North Bell | Rehearsal booking emails

For the outside customer-service writer drafting replies to people arranging a rehearsal. Use this guide to tell the organizer how to ask about a room, what North Bell will send back, and when a room can be held.

## Booking language

The three booking facts below are owner-approved. The rewrites are suggested wording. Each example addresses the organizer as “you” and speaks for North Bell as “we,” as the public booking message does.

| Cue from the public booking message | What to write | Before | Suggested rewrite |
| --- | --- | --- | --- |
| The organizer emails a day and a player count. | Ask for both details in the same sentence. Use “players” so the organizer knows whom to count. | “Please send us your rehearsal details.” | “Which day would you like to rehearse, and how many players are coming? Email us both details.” |
| North Bell replies with available rooms. | Name who replies and what the organizer will receive. | “Your inquiry will be processed.” | “We’ll email you back with the available rooms.” |
| The organizer must confirm by email before a room is held. | Say who confirms, by what channel, and how confirmation relates to the hold. | “Once you hear from us, your room is held.” | “We can hold a room only after you confirm by email.” |

## When a customer thinks the room is already held

If the organizer has received the available rooms and asks whether one is on hold, write something like “Please confirm your room choice by email. We can hold it only after you do.” This gives the customer the next action and keeps the hold conditional.

## Scope

This provisional guide covers rehearsal booking correspondence. For a new public piece that will invite email inquiries, get North Bell’s approved booking email address before publication. Send questions about other booking terms to North Bell for approved wording. Visual identity is unverified.
