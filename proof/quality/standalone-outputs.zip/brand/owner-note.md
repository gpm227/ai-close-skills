# North Bell | Owner reference

For the owner’s records. Send only `North-Bell-writer-guide.md` to the outside writer.

| Material | Status and decision |
| --- | --- |
| Owner-supplied public booking message, sentence 1 | Inspected. “email us the day and number of players” supports the rehearsal intake rule. |
| Same message, sentence 2 | Inspected. “We will reply with available rooms.” supports the availability reply. The message gives no response time or actual email address. |
| Same message, sentence 3 | Inspected. “A room is held only after you confirm by email.” establishes a necessary condition for a hold. The guide makes no promise about when a hold will be processed. |
| Private staff note in the owner's brief | Internal. The owner restricted the note to internal use. Its content contributed no rule, claim, or example to the writer guide. |
| Deck and website | No deck supplied. Website reported inaccessible. Neither was inspected. Visual rules remain open. |

The approved excerpt supports the booking facts. Pronouns and action order are observed in that excerpt. All proposed rewrites preserve the original division of responsibility. Before releasing any public copy that needs an email destination, supply and verify the booking address.
