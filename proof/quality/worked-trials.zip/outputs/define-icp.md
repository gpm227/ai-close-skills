# Qualification card | Reusable instrument-tray returns

Qualify each clinic receiving site separately. The clinic needs someone to receive its returned trays every Friday. A network's headquarters, total room count or another branch's technician cannot establish that a particular site can receive a return.

| ID | Type and authority | Exact test | Evidence each rep records | Unknown |
|---|---|---|---|---|
| G1 | Hard gate, owner-approved | Depot to receiving site is **≤40 road miles**, inclusive. Measure the road route used for service. | Receiving address, depot, recorded road-route distance and source/date. Use the same service route when rerunning the check. | Needs evidence unless another gate already fails. |
| G2 | Hard gate, owner-approved | A **named technician** at that site is available to receive the return **every Friday**. | Technician name, site and explicit standing Friday confirmation from the clinic or its receiving schedule, with date. A one-off Friday or an unconfirmed job title is insufficient. | Needs evidence unless G1 already fails. |
| S1 | Descriptive signal only | Record operating rooms if known. No approved minimum, maximum or room-based ranking. | Supplied clinic history or site report. | No effect on eligibility. |

**Apply in this order:** A verified failure of either gate yields **excluded**, including when the other gate is unknown. Both verified passes yield **eligible**. Otherwise record **needs evidence**, the missing field and the question that resolves it. Recheck G2 when a named receiver leaves.

| Case | Gate evidence | Result and action |
|---|---|---|
| P | 39 road miles. Named technician available Fridays. One room. | **Eligible.** Both hard gates pass on the referral as supplied. Carry the technician's name from the referral into the site record. |
| Q | 12 road miles. Five rooms. Friday coverage unspecified. | **Needs evidence.** Ask “Who can receive the tray return at this site every Friday, and can you confirm that standing arrangement?” |
| National network example | 70 miles, 20 rooms. | **Excluded** for the referenced receiving site under G1. Size cannot override service distance. |
| Illustrative boundary | Exactly 40 road miles and confirmed named Friday technician. | **Eligible.** At any verified distance over 40, exclude. |

**Source ledger:** O1, owner's service statement (first sentence); H1, three retained clinics with 2, 5 and 7 rooms met both gates; H2, churn followed the receiving technician's departure; H3, 70-mile network example; R-P and R-Q, two referral descriptions. Dates were not supplied. The history supports rechecking receiver continuity. It does not establish a room-count rule or prove the departure caused churn. An exception beyond 40 miles or without a named Friday receiver requires the owner to change the corresponding gate. Q instead needs coverage evidence.
