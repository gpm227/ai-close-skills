# Member instructions | editing brief

Tell the member what to do with the thing in front of them. Use the timing and conditions the service can actually honor.

| Status | When to apply the rule | Edit and exception | Example and source |
|---|---|---|---|
| Observed | A line promotes access, membership or a “solution.” | Start with the member's action and name its object. Add the verified place or duration when it helps. If the action or object is missing, ask the service owner. | “Unlock our seamless lending solution” → “Borrow a tool for a week.” V1. “Complete submission to gain access” → “Show your card at the desk.” V2. |
| Observed | A benefit or instruction has practical conditions. | Replace vague or absolute language with the actual step, time or place. Keep any condition that affects the outcome. Use only details supplied for this transaction. | V2 replaces generic access with showing a card at the desk. V3 replaces “Never incur late charges” with “Return the tool by Friday to avoid the late fee.” |
| Proposed | A fee claim is unconditional. | State the action that avoids the fee and its verified deadline. Confirm whether the fee applies to this service. | Teaching example: “Avoid every fee” → “Return the drill by the due date to avoid the late fee,” if the service terms say so. V3 is the sole fee example. |

**Evidence boundaries.** V1, V2 and V3 are three supervised before/approved-after pairs supplied by the owner. Editor identity, formal adoption, placement and date are unspecified. The instructional reader appears to be a borrower or member. No channel-specific convention can be inferred. “Friday,” “a week” and “at the desk” are service facts in individual examples. The owner should approve any guide-wide rule about fees.

### V4 holdout

Only V1–V3 supplied the rules. Both halves of V4 were visible in the request, so this is a disclosed retrospective check. There was no blind or independent editor test.

| Item | Result |
|---|---|
| Draft | “Leverage your member privileges instantly” |
| Guide-based edit using the draft alone | “Use your membership benefits.” This removes the jargon and the unsupported timing claim. It still leaves the member without a concrete action. Editorial query: Which benefit is this, and what must the member do to use it? |
| Owner's approved V4 | “Bring your card to collect the key.” |
| Verdict | Partial match. The guide correctly asks for a direct instruction and flags “instantly.” It cannot recover the card or the key from V4's draft. Importing “card” from V2 would still be an unsupported transaction-specific guess. With the missing service facts, the owner's line satisfies the guide. |
