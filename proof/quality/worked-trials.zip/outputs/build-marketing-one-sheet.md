# Costume checkout one-sheet

[Forwardable one-page PDF](build-marketing-one-sheet/costume-checkout.pdf) · [Editable self-contained HTML](build-marketing-one-sheet/costume-checkout.html)

The reader gets numbered garment tags and a checkout sheet. The page walks a volunteer coordinator through tagging a garment, recording the borrower and planned return day, and looking up a loan. A clearly labeled fictional row shows how the information fits together.

### Editor's evidence and production note

| Item | Basis and disposition |
|---|---|
| Offer and responsibilities | O1 supplies the tags, checkout sheet and coordinator's recording task. |
| Action | The supplied form accepts an email. A coordinator replies with a sample pack list. Both screen links and the printed URL identify `https://loom.example/request`. The PDF link target was checked locally. The endpoint and reply were described by the owner and were not tested live. |
| Pricing | No public price or quoting process was supplied. The sheet is unpriced. |
| Evidence and visuals | P9 is internal and uncleared. It is absent from both buyer files. The example row is illustrative. The page uses type and a table, with no logo or photography. |
| Print | Used US Letter, since the request specified no size. Rendered the HTML content into a 612 × 792 pt PDF. Checked the single page, the sample row, line wrapping and the full final URL in the rendered page. |
