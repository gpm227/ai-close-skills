# Editor seats for 18 months

Choose **Alder**. Buying exactly 15 seats for all 18 months costs $7,160 before tax. Birch requires $7,200 in nonrefundable payments to cover month 18. Alder saves $40 and allows monthly cancellation.

| Buyer requirement | Alder quote | Birch quote |
|---|---|---|
| Exactly 15 usable editor seats | Met on quoted seat basis. 10 included plus 5 additional seats. | Met on quoted seat basis. 15 included. |
| Continuous availability for 18 months | Met by taking 18 monthly periods. | Met by taking two 12-month terms, covering 24 months. |

| Pre-tax dollars | Alder | Birch |
|---|---:|---:|
| Recurring price | $280 + 5 × $18 = $370/month | $3,600/12-month term |
| Setup | $500 | $0 |
| Price allocated to 18 months of service, including setup | $500 + 18 × $370 = $7,160 | 18 × ($3,600 ÷ 12) = $5,400 |
| Cash required to cover the period | $7,160 across setup and 18 monthly charges | $3,600 at start + $3,600 at month 13 = $7,200 |
| Cash tied to months 19–24 | $0 if service ends after month 18 | $1,800 already prepaid, with no refund |
| Minimum obligation when starting, then total commitments incurred to cover the need | $870 for setup and first month, then $7,160 in all | $3,600 for the first term, then $7,200 in all |

The $5,400 allocation is a service-value calculation. Birch’s no-proration, no-refund clause makes $7,200 the amount the buyer must commit. Both quotes exclude identical tax. The quoted seats are treated as editor seats as described in the request.

**Negotiation.** Procurement should ask Birch to keep its first term at $3,600 and cap the second payment at **less than $3,560** with no further fees or renewal obligation. A $40 discount ties Alder. With cent pricing, a $40.01 discount wins by one cent ($7,159.99); a $39.99 discount leaves Birch one cent higher ($7,160.01). A six-month prorated final term at the existing rate would be a more valuable concession: $1,800 for the extension, $5,400 total and $1,760 saved versus Alder. A change in billing dates alone leaves the obligation intact.
