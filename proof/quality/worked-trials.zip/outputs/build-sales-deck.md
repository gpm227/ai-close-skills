# Tool-lending co-op meeting

[Download the editable, four-slide deck with speaker notes](build-sales-deck/checkout-trial.pptx)

## Slide 1 · Should we try the checkout system in one bay?

One storage bay. Two weeks. One shift lead.

The co-op can run the trial or keep its current checkout process. Today’s vote covers the trial only.

Source: co-op meeting brief and S1.

**Speaker notes.** Ask members which bay could support the trial. The alternative is to continue the current process. If someone asks whether a yes vote commits funds, the proposal authorizes no purchase. Pilot pricing and staff time are unspecified; the co-op should clarify either before committing resources. Next: show what would change in the chosen bay. Source: meeting brief, vote scope; S1, lead requirement.

## Slide 2 · Bin cards pair with a daily check sheet

Co-op

Choose one storage bay and appoint one shift lead.

Pilot materials

The supplier can send the bin cards and daily check sheet after the bay and lead are named.

Proposed daily check: have the lead compare the cards with the sheet and flag checkouts still unresolved.

Source: S1. The daily review described here is a proposed pilot routine.

**Speaker notes.** The buyer appoints the shift lead. Materials can arrive once the co-op identifies the bay and the lead. If asked when supplies will arrive, the supplier should confirm timing after the names are provided; no date has been promised. The daily comparison is a suggested way to use the two records. Next: agree how to tell whether the routine is worth the work. Source: S1 and the supplied materials condition.

## Slide 3 · What should the lead count?

At each daily check

Record total checkouts, how many remain unresolved and minutes spent checking.

At the end of two weeks

Review the counts and staff time. Compare with the same bay’s prior two weeks only if comparable records exist.

Source: proposed measurement plan. No measured impact or approved price was supplied.

**Speaker notes.** Define unresolved before starting, for example a checkout whose status the lead cannot reconcile at the daily check. Preserve the numerator and total for each check. An item may stay open across checks, so do not add open counts as unique checkouts. If there is no comparable prior record, report the pilot observations and burden on their own. Ask what amount of daily work the co-op can support; the lead can bring the records back for review. Next: ask for the motion. Source: trial duration from the brief; measures, baseline and review date are proposals.

## Slide 4 · Vote on the two-week, one-bay trial

Motion: try bin cards and a daily check sheet in one storage bay for two weeks.

This vote authorizes no purchase. If approved, the co-op names the bay and appoints its shift lead. The supplier can then arrange materials. If declined, keep the current process.

Source: co-op meeting brief and S1. Start date and review timing remain to be agreed.

**Speaker notes.** Chair: put the motion to a vote. This vote covers the trial alone and makes no purchase decision. If it passes, record the bay and lead at the meeting if possible, then ask the supplier to confirm delivery and agree a start date. Propose that the lead report after the two weeks. If the motion does not pass, retain the current process. Likely question: can we start before naming the bay and lead? The supplier needs both before materials can arrive. Close by recording the vote and any assigned owner. Source: brief, materials condition; S1, buyer-appointed lead.

## Internal source and release record

Meeting brief: slides 1 and 4 establish the vote, one bay and two weeks. S1: slides 1, 2 and 4 establish paired bin cards and daily check sheet, the co-op-appointed shift lead and the requirement to name the bay and lead before materials can arrive. Slide 3 is a proposed measurement plan. Price, prior counts, meeting length and exact arrival date are unspecified. The past co-op statement P1 is limited to internal training and was excluded from all buyer-facing slides and notes.

The four-slide PowerPoint has native editable text and four populated speaker-note records. The exported deck was rendered for a layout check.
