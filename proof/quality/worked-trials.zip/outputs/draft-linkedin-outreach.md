# Cam | Draft LinkedIn outreach

**Connection note — usable for a new invitation only**

Hi Cam, I saw “working with volunteers” on the agenda for your October talk. I'd like to connect.

**DM — usable only after Cam accepts, if there is no reply or active conversation**

Thanks for connecting, Cam. We have a volunteer sign-in worksheet. Would you like a copy?

**Coordinator handoff.** No connection or reply is reported. Check whether an invitation is already pending before using the note. Leave a pending invitation alone. If Cam replies, handle their message individually. A decline or opt-out ends the sequence. A second DM is omitted because the worksheet is the only supplied resource and repeating the offer adds nothing.

**Sources.** The October public agenda lists “working with volunteers” for Cam's talk. It supplies no recording or remarks. Cam's collections-director role, the absence of a prior relationship and the availability of the worksheet on request come from the brief. Neither message implies attendance. All text is draft only.

**Final invitation length:** 97 characters including spaces and punctuation.
