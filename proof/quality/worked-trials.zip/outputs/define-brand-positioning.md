# Overlay Ferry positioning brief

**One-sentence intro.** Overlay Ferry gives dispatch a shared departure log that shows when a departure's dock changed.

| Decision | Working brief |
|---|---|
| Primary reader and buying moment | A branch operator whose departure board lists sailings but leaves dock changes unrecorded. The operator is deciding whether dispatch needs a shared record of those changes. |
| User and beneficiary | Dispatch uses the log. Branch operators seeking a record benefit. The budget holder, approver and other users are unconfirmed. |
| Category | Shared departure log. |
| Reason to choose it | Dispatch can look up a timestamped dock change against the departure it affects. The fact sheet supports the capability. Two of three win calls support the reason to choose it in this small sample. |
| Alternatives and fit | A whiteboard can be enough when the team only needs the departure list. Teams could also add a change record to their board if they can keep it shared and current. For live vessel location, a fleet tracker with GPS fits the requirement. Overlay Ferry neither tracks vessels nor predicts delays. |
| Open question | Ask the next branch operator: “Walk me through the last dock change. Who needed the record, what did the team do with it, and who decided whether to replace the board?” |

### Spoken version

How does dispatch check which dock a departure was moved to? If the board shows the sailing but misses the change, Overlay Ferry gives dispatch a shared departure log. The dock change sits with the departure and carries a timestamp. Someone looking back can see what changed and when. If the board already captures everything your team needs, you may be set. If the question is where the vessel is right now, look at a fleet tracker with live GPS. Overlay Ferry handles the record of dispatch's dock changes. It also leaves delay forecasting outside its scope.

### Internal decision ledger

| Locator in supplied brief | Evidence type and decision | Scope |
|---|---|---|
| Win-call summary, two of three operators | Buyers reported that the whiteboard omitted dock changes and wanted a shared record. Primary buying hypothesis. | Directional evidence from two wins, summarized and undated. No customer quote cleared for publication. |
| Win-call summary, third buyer | Buyer praised personal support. | Single mention. Insufficient for a service-level promise or a primary positioning claim. |
| Product fact sheet, shared departure log and stated exclusions | Product evidence for dispatch, shared log, timestamps, dock changes and exclusions. | Capability supported. No documented reduction in errors or time. |
| Loss L1, fleet tracker selection | Buyer selected a general fleet tracker for live GPS. | Actual non-fit. Branch decision maker and payer roles beyond the supplied facts are inferred or unknown. |
