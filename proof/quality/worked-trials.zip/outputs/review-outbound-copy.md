# Outbound draft review

**Clean copy for owner review**

> Saw your board is considering an opening. Two of five pilot galleries reported fewer errors. Would you like our coordinator to schedule a worksheet call?

| Location and original wording | Evidence and issue | Edit |
|---|---|---|
| Opening: “Saw your opening next month.” | P4 says the board is considering an opening. The decision and date are unconfirmed. | “Saw your board is considering an opening.” |
| Proof: “Every gallery cuts intake errors in half with us.” | C2 supports a self-reported improvement at two of five pilot galleries. It gives no measured magnitude or basis for a universal or causal claim. | “Two of five pilot galleries reported fewer errors.” |
| Action and fulfillment: “Book your free audit today and we’ll deliver your score now.” | D6 routes an enquiry to a coordinator who schedules an optional worksheet call. No free audit, score, immediate delivery or same-day availability is documented. | “Would you like our coordinator to schedule a worksheet call?” |

**Status: ready for owner review, draft only.** The revision keeps the brief opening, specific reported benefit and short ask. It requests one action: reply about an optional worksheet call. Scheduling belongs to the coordinator. P4, C2 and D6 support the remaining factual language. A confirmed opening date, measured error reduction or approved audit terms would be needed to restore the respective original claims. No message was sent.
