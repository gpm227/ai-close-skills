# Post

I labeled eight bins last Thursday. With the light off, I mixed up two that looked alike.

We added the bay numbers by the door. I want to know whether I can use those numbers to tell the same two bins apart when the light is off. We haven’t tested that change yet.

Here’s the check I’d run. Start at the door. Find a bay number. Go to the bin you think it belongs to. Then check which bin you actually picked. If you have to guess between the same two bins, write that down.

For now, I can tell you what happened on Thursday and where we put the numbers afterward. I still have to try it again with the light off.

### Alternate first line

With the light off last Thursday, I mixed up two of the eight bins I’d labeled.

Use the alternate in place of the **entire opening paragraph** so the observation appears once.

### Pre-post claim check

| Material | Source and clearance decision |
|---|---|
| First-person Thursday observation, eight bins, two similar-looking bins mixed up with the light off | Workshop lead's own supplied notes. Counts describe that occasion only. |
| “We” added bay numbers by the door and have yet to test the change | Same notes. Collective attribution retained. The walkthrough is a proposed test, clearly distinguished from an observed result. |
| Voice | One approved sample supports a short imperative and a concrete physical check. The post uses “Start at the door.” It borrows no event from the sample. |
| Names and results | No site or individual named. The draft makes no statement about errors after the change. |

If posting after a new test or in a later week, have the lead confirm the current test status and replace “last Thursday” with the actual date or “one Thursday.” This is draft copy.
