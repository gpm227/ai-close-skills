# Nightly inventory exception queue · design for owner review

For every in-scope inventory exception line, keep one queue item for its depot, work order and line number at the highest accepted revision. Two lines on one order must remain separate. The only business write is the warehouse queue upsert. This is a design; no deployment or live test occurred.

**Input contract.** Warehouse operations owns the source exception definition and the queue fields. If the CSV already contains only exception lines, each valid row qualifies. If it contains all inventory lines, the owner must specify an exception predicate before enabling writes. An absent line in a later file carries no instruction to close or delete an item.

| Source / derived field | Type and validation | Destination / use |
|---|---|---|
| depot_id | Required opaque ID; preserve case and leading zeroes | Store as depot_id; first object-key component |
| work_order | Required opaque ID; preserve original identity | Store as work_order; second component |
| line_no | Required source line identifier; preserve its representation until the owner defines a numeric canonicalization | Store as line_no; third component. Blank → row review |
| revision | Required integer under the source contract; reject malformed values; compare numerically | Store as last_revision with the accepted business payload |
| Approved exception detail | Copy only the inventory fields in the owner-approved schema; payload columns were not supplied | Queue item data; retain a canonical payload or its digest to detect conflicting repeats |
| Object key | Unambiguous, lossless encoding of ordered tuple [depot_id, work_order, line_no], e.g. canonical JSON array | Unique external key on queue item |
| Event key / effect key | Event key = encoded tuple [depot_id, work_order, line_no, revision]; effect key = [event key, "queue-upsert"] | Stable through redelivery and retries; file name and attempt ID stay out of both keys |
| File locator, row number, attempt ID | Capture input reference, row locator, fresh attempt ID and schema version | Attempt log only; retain validation result, event/effect keys, step, accepted revision and receipt where available |

**Node sequence**

1. On nightly file arrival or scheduled pickup, register the file and preserve its rows for replay. Process late files the same way as on-time files. A file checkpoint advances after each row has a durable applied, superseded, identical-repeat, or held outcome. A repeated file may be read again safely.
2. Parse the agreed CSV schema. Quarantine an unsupported file schema. For a bad row, save the file/row and reason before any queue write and continue with independently valid rows. A missing line number cannot be reconstructed from the work order or row position.
3. Build the keys and compare the incoming revision and business payload. Atomically insert an absent item or replace an existing item only when its stored revision is lower. Commit payload and revision together. For equal revisions and equal payload, record a repeat with no mutation. For equal revisions with different payloads, keep the existing item and quarantine the conflict. Ignore an older revision as superseded.
4. The queue needs a unique external key and an atomic revision comparison, e.g. a conditional upsert or compare-and-swap with a version check at commit. Plain upsert followed by a log entry still permits a stale overwrite. If the queue exposes only unconditional upsert, require a durable single writer per business key plus serialization of uncertain in-flight requests before release; hold that key on ambiguous acceptance. The queue owner must verify the chosen concurrency contract before activation.
5. Record the outcome and receipt. On lost acknowledgement, read the queue by object key. Equal revision and matching payload confirms completion; a higher stored revision supersedes the event. A lower revision or absent object can be retried using the same conditional effect. An unresolved conflict or unreadable destination stays held. Use bounded, jittered backoff for timeouts/throttles (proposed: three retries); pause on authentication/configuration failure for the integration owner. Replaying starts at the affected row, with its original event identity. The operator can stop the worker and retain the backlog.

**Acceptance cases, designed for a staging queue**

Each case starts with an empty queue unless a seed is named. “Writes” counts applied business mutations, excluding log entries. Use depot D, order W and sample payloads p and q.

| Inputs in arrival order | Expected queue contents | Expected writes / other outcomes |
|---|---|---|
| W line 1 rev 1 p; W line 2 rev 1 q | Two separate items at rev 1 | 2 writes |
| Two concurrent copies of W line 1 rev 1 p; same file redelivered later | One item at rev 1 p | 1 write total; subsequent copies are identical repeats |
| W line 1 rev 1 p, then rev 2 q | One item at rev 2 q | 2 writes; one update |
| W line 1 rev 3 q, then late rev 2 p | One item at rev 3 q | 1 write; 1 superseded |
| W line 1 rev 2 and rev 3 race with different payloads | One item with rev 3 payload | 1 or 2 writes according to commit order; no stale overwrite |
| W line 1 rev 2 p, then rev 2 q | One item at rev 2 p | 1 write; conflict held for source owner |
| W blank line_no rev 1 p plus valid W line 2 rev 1 q | Only line 2 at rev 1 q | 1 write; bad row held with locator |
| W line 1 rev 1 p commits; acknowledgement lost; same event retried | One item at rev 1 p | 1 write total; reconcile receipt or read back matching payload |

Before any later cutover, the warehouse owner should confirm the schema, queue destination, exception selection and update semantics. The integration owner should test the cases above, reconcile proposed rows against a read-only sample, and establish a monitored dashboard for input, accepted, held and retry counts. On unexplained mismatches, stop consumption and reconcile affected keys. No notification step is part of the workflow.
