# Tern Kiln | Equipment-service scheduling

**The existing kiln line now runs Saturdays. Opening question:** “Since the line began running Saturdays, how, if at all, has that affected when you schedule equipment service?”

| Source | What the extract establishes | What the rep can say |
|---|---|---|
| Nov 10, staff note S4 | The existing line now runs Saturdays. The start date and previous service schedule are unspecified. | Ask about the current line's service windows. |
| Nov 2, board minutes B7 | The board authorized a feasibility study for a second kiln line. Capital expenditure was not approved. | Ask whether scheduling is in scope for the study if the topic arises. |
| Undated, unsigned aggregator A9 | Claims the plant “doubled capacity.” No production figures or commissioning record accompany it. | Capacity growth is unverified. Omit the claim from the opening. |

**Two possibilities to test**

1. Saturday production could displace a service window **if** the team previously used Saturday for maintenance. Ask when the last two service visits happened. If both fell in unaffected standing windows and the team says those windows still work, drop this line of inquiry. Basis: S4.
2. The feasibility study could create a reason to compare service schedules **if** the team is evaluating maintenance coverage for a second line. Ask what the study covers. If it excludes service planning, stay with the existing line. Basis: B7.

The offer concerns coordinating service visits around operating windows. The evidence identifies Tern Kiln and its existing line, but gives no site or subsidiary details, scheduling owner, internal process, provider, maintenance history or CRM relationship. Avoid assuming a missed service visit. Before the call, recheck whether S4 still reflects the operating schedule and whether a later board decision changed the second line's status.

**Confidence:** high in the two primary-source statements as supplied, low in either operational hypothesis pending discovery.
