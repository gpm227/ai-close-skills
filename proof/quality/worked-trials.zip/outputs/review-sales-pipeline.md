# October 1 to November 1 open pipeline

Gross open pipeline fell **$30k**, from **4 deals / $230k** to **3 deals / $200k**. The two snapshots cover the same team. All amounts below are USD thousands.

| Snapshot or movement | Deal evidence | Change in open count | Change in open value |
|---|---|---:|---:|
| Opening balance | A 100, B 60, C 40, D 30 | 4 | 230 |
| New | E opened in Qualify at 80 | +1 | +80 |
| Won | B left Demo, won at 60 | −1 | −60 |
| Lost | C left Demo, lost at 40 | −1 | −40 |
| Continuing deal decreased | A remained in Proposal, 100 → 70 | 0 | −30 |
| Continuing deal increased | D moved Qualify → Demo, 30 → 50 | 0 | +20 |
| Closing balance | A 70, D 50, E 80 | 3 | 200 |

Count reconciles as 4 + 1 − 1 − 1 = 3. Value reconciles as 230 + 80 − 60 − 40 − 30 + 20 = 200, leaving zero residual. B contributed $60k of wins in the supplied history. D’s stage transfer moved its opening $30k between stages; only the $20k expansion changed total open value.

| Open stage | Oct 1 count / value | Nov 1 IDs | Nov 1 count / value | Value change | Share of closing value |
|---|---:|---|---:|---:|---:|
| Qualify | 1 / 30 | E | 1 / 80 | +50 | 40% |
| Demo | 2 / 100 | D | 1 / 50 | −50 | 25% |
| Proposal | 1 / 100 | A | 1 / 70 | −30 | 35% |
| Total | 4 / 230 | A, D, E | 3 / 200 | −30 | 100% |

**Rep exceptions and meeting decisions**

| Priority | Owner to act | Exception | Decision or next action |
|---|---|---|---|
| 1 | D’s assigned rep | As of Nov 1, 50 days have elapsed since Sep 12. D has no next step despite a stage advance and $20k increase. | Check the customer evidence for stage and amount, then enter a dated buyer action or propose a corrected stage and amount. No team staleness threshold was supplied. |
| 2 | A’s assigned rep | Proposal value fell $30k (30%) while stage stayed the same. | Confirm the revised scope and reason for the reduction, and bring the next buyer milestone to review. |

The manager should identify the named owners from the CRM. The excerpt supplies no owner names and omits next-step fields for A and E; their omission does not establish that either CRM field is empty. Closed B and C have confirmed exits. No quotas, win probabilities, or evidence of deals opening and closing between snapshots were supplied. This review measures snapshot movement; forecast attainment is unknown.
