# November pilot

| Outcome at the supplied November cutoff | Distinct recipients | Denominator and rate |
|---|---:|---|
| Attempted, one touch each | 100 | Pilot population |
| Delivered | 90 | 90/100 attempted = 90% |
| Hard bounced | 10 | 10/100 attempted = 10% |
| Any reply, including automatic | 12 | 12/90 delivered = 13.33% |
| Automatic absence | 3 | 3/90 delivered = 3.33% |
| Human reply, including opt-outs | 9 | 9/90 delivered = 10.00% |
| Interested | 2 | 2/90 delivered = 2.22% |
| Human opt-out | 1 | 1/90 delivered = 1.11% |
| Other human reply | 6 | 6/90 delivered = 6.67% |
| Delivered with no recorded reply | 78 | 78/90 delivered = 86.67% |
| Opens, booked appointments, held appointments | Unknown | Unmeasured |

Delivery reconciles to 90 + 10 = 100. The 12 replies comprise 3 automatic, 1 opt-out, 2 interested, and 6 other human replies. Each person replied at most once. Counts describe the supplied aggregate; send dates, precise cutoff/timezone and equal follow-up time are unavailable. Two interested replies cannot establish an appointment rate.

Sender X received all 65 warm prospects and sender Y the remaining 35 cold prospects. Warmth and sender are inseparable in this pilot. Even sender-specific outcome totals would not identify a sender effect.

**Draft experiment for owner review.** Test only the closing question: keep the existing closing question in the control and change it to “Is this a priority for you this quarter?” in the variant. Within each existing sender/list group, randomly assign eligible recipients 1:1, one variant per person; use identical body text, send timing, follow-up and interest classification. Exclude prior opt-outs and hard-bounced addresses. Measure distinct interested humans divided by distinct delivered recipients per arm within seven complete days of the touch, reporting each sender/list group and the pooled arms. Track hard bounces / attempts and opt-outs / delivered per arm as guardrails.

Proposed review date is December 15, 2026, assuming all pilot touches finish by December 7 local time. Review after every included recipient has completed seven days. Label the comparison exploratory until the owner agrees the eligible volume, minimum improvement and guardrail limits before assignment. No winner or rollout decision follows without those criteria. No sends were made.
