# Paid digital banner | January 8–20, 2027

**Send the buyer the reference for A1, `/brand/v3/wordmark-light.svg`.** The manifest identifies v3 as the current, approved company-owned wordmark for dark surfaces across all channels. Navy is the intended background. File delivery and final artwork approval are pending access to the master and a render at the banner's actual dimensions.

| Asset | Decision | Rights or production basis |
|---|---|---|
| A1 · `/brand/v3/wordmark-light.svg` | Select the reference for the logo. | Manifest lists dark surfaces and all channels. No end date or territory restriction is stated. |
| A2 · `/brand/v4/draft-wordmark-white.svg` | Withhold. | Proposed only. The newer version number does not confer release approval. |
| A3 · `/library/harbor.jpg` | Withhold. | Licensed only for organic social and only through December 31, 2026. Paid digital is outside scope and the entire flight falls after expiry. |
| A4 · `/library/harbor-alt.jpg` | Withhold. | Usage status unknown. Require an owner or licensor record for paid digital covering the flight and intended territory. |

**Handoff.** Use a navy, wordmark-only layout if photography is optional and A1 passes proofing. If a photo is mandatory, there is no approved match in this manifest. All four entries are supplied references. No file was opened, delivered or rendered, and path existence has not been verified.

**Production check.** Obtain the released A1 master, navy value and final banner dimensions. Open the SVG and verify the viewBox, aspect ratio, any embedded raster resolution and the ad platform's accepted format. Render at the delivery size and check the edges, legibility and clearance on navy. If the logo conveys the brand identity, use the verified brand name as its accessible text. If the same name is already present as accessible text, treat the duplicate mark as decorative.
