# Practice room copy

### Homepage

Request a practice room for one hour. Staff reserve the room once they confirm your time.

**Button**  Request a time

### In-app alert after submission

We saved your preferred time. Staff still need to confirm your room.

### Service email after staff confirmation

**Subject**  Room 2 for Friday at 10 a.m.

We’ve reserved Room 2 for you on Friday from 10 to 11 a.m.

### Editing checks

| Touchpoint | Reader's question and useful length | Before → after | Action or state check |
|---|---|---|---|
| Homepage | How do I get a room? Two short sentences and a verb-led button. | “Book an hour now” → “Request a time.” Keep the one-hour limit and staff confirmation condition in the adjacent line. | P7. The button leads to a preference form. Submitting it supplies a preferred time, without reserving a room. |
| In-app alert | Did my submission work? Two short sentences. | “You're booked” → “We saved your preferred time.” Say what the form recorded and who acts next. | P7. Show immediately after a successful submit. No room, day or hour has been confirmed at this point. No action button needed. |
| Service email | Which room and when? Put room, day and start time in the subject, then confirm the whole hour in one sentence. | “We received your request” → “We’ve reserved Room 2 for you.” Switch to the confirmed state and add its particulars. | P7 plus the specific staff confirmation. Friday 10–11 a.m. is the one-hour interval beginning at 10 a.m. Send only after confirmation. No second booking action. |

All three examples use short active verbs and omit exclamation marks. The flow and states come from the supplied policy and case. No live form was inspected. No owner-imposed character or word limits were supplied.
