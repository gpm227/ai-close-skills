# Can you read the crate label from the aisle?

Stand where your team will read the crate ID before you choose a spot for the label. On one intake day, three of the five crates had labels facing the wall. The team had to rotate those crates to read them. A label that reads clearly at the packing table can disappear once the crate is in place.

A rule that every fixed label should face the aisle breaks down when the aisle is narrow. At another site, the team uses hanging tags in narrow aisles. The choice turns on what the reader can reach and see once the crate is in position.

At your next intake, stand where a colleague will go to find each crate. Ask them to read its identifier from there. Record which identifiers they can read without moving a crate. Where the fixed label is hidden, try a hanging tag if the space permits, then repeat the check from the same spot. Use the arrangement your colleague can read.

### Editor's argument map

| Claim or decision | Basis | Limitation |
|---|---|---|
| Choose the label position or tag after testing the reader's view. | Inference and proposal drawn from N1 and N2. | Applies to identifying stored crates from their access position. |
| Three of five crates needed rotation for reading on one intake day. | Observed, N1 field notebook. | One day, one intake. No timing, trend or prevalence claim. |
| Fixed labels cannot always face the reader in a narrow aisle. A second site uses hanging tags. | Reported, N2. Strongest objection to a uniform fixed-label orientation. | The note establishes use, without a measured advantage for tags. |
| Compare readability before specifying a fixed label or tag. | Proposed field test. | If readers can read all fixed labels in their normal stored positions, these notes give that team no reason to switch to tags. If both formats are obscured, change placement and test again. |

The sites remain anonymous. The draft paraphrases the field notes without assigning the conservator an unverified firsthand role. The supplied voice line governs the direct instruction in the opening.
