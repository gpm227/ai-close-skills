# Landing page

### Headline · desktop and mobile

Onsite crate-wash training for one greenhouse crew

### Opening

A trainer comes to your greenhouse, demonstrates the crate-wash steps and leaves your crew a laminated checklist to use at the wash station.

### What the visit covers

Your crew can watch the wash steps onsite and refer to the checklist afterward. Each visit covers one crew. Lab testing and certification are outside the session.

### Request a visit

Enter your postcode and preferred date. A coordinator checks whether your postcode is in the service area before replying. Your preferred date is a request.

**Button · desktop and mobile**  Request a visit

**Destination**  https://fern.example/visit

### Form confirmation copy

We received your postcode and preferred date. A coordinator will check coverage and get back to you.

### Editor's evidence and path check

| Placement | Claim, qualifier or action | Evidence and status |
|---|---|---|
| Headline, opening and scope | Onsite demonstration, laminated checklist, one crew per visit. No lab testing or certification. | S2, reported service terms. Checklist use at the wash station illustrates its purpose. Price and visit duration were unspecified and are left unstated. |
| Button and request section | Same 15-character CTA on both layouts. It opens a request form asking for postcode and preferred date. | Exact destination above, described by the owner. Form and responsiveness were not exercised. |
| Confirmation | Acknowledge receipt following a successful submission. Coverage is checked before a response. | Proposed success message written from the supplied flow. No appointment, service eligibility or response time is promised. |
| Outcomes | No quantitative proof block. | Private trial note lacks public permission. No rejection-rate or performance claim in the page. |

The reader can identify the service, review coverage limits, open the form, submit a preference and understand what happens next. The entry ad or referrer was unspecified, so the headline stands on its own.
