# Existing visual standard

Released web tokens govern the web palette and typography. The print master governs logo clearance on print. This record is based on the owner's inventory. The source files, fonts, logo and printed output were unavailable for inspection.

| Role, channel and state | Value or observation | Authority and use |
|---|---|---|
| Web page background, default | `#FBF7E8` | Specified by released `tokens.css` r7. |
| Web text, default | `#273B40` | Specified by r7. Use on the background token. |
| Web action, default | `#914A19` | Specified by r7. The unapproved sales comp proposes bright pink. A JPEG corner appears pink according to the inventory. Neither establishes a new action token. |
| Web typography | Georgia for headings, Arial for body | Specified by r7. Sizes, weights, selector names, exact fallback stacks, installed font availability, embedding and redistribution rights were not supplied. Keep semantic heading levels. |
| Web spacing | 8, 16, 32 px | Specified by r7. The scale is released. Assignment of each step to a particular component is unverified. |
| Links, focus, hover, disabled and status colors | Unspecified | Request the released component states. Preserve descriptive text for statuses such as “No records” or “Date required.” Color alone cannot explain them. No icon or chart style was supplied. |
| Print logo | Keep clear space of one cap height around the mark | Specified by print master P2. Use that master's cap-height reference at final size. Approved logo URL, variants, minimum size and artwork are missing. |
| Print color, type and layout | Unresolved | No CMYK or spot equivalents, stock, page size, margins, print type settings, or approved grayscale treatment supplied. The web hex values do not define press values. |

### Application recipes

These are examples of applying the existing roles. The dimensions and component spacing assignments below are proposed test settings only.

* **Desktop, 1280 × 800 px.** Put a Georgia heading and Arial body on the r7 background. Try 8 px between heading and text, 16 px before the action and 32 px between content sections. For an underlined textual action, use the action color on the page background. No approved content width is recorded.
* **Phone, 360 × 800 px.** Keep the same roles in one column with 16 px side padding. Try a two-line action such as “Request the complete collection inventory.” Allow the action to grow vertically. At an empty state, show “No records” in the body style. Verify wrapping, keyboard focus and all interaction states in the actual component.
* **Print at final trim.** Obtain the P2 master and approved logo. Measure one cap height from the supplied mark, then keep that area clear on all sides. Inspect a final-size grayscale proof for label hierarchy, readable actions and logo separation. Hold color conversion, trim, margins and logo placement for the print owner and printer where specifications are absent.

### Contrast and verification

Calculated from the released RGB values using relative luminance. In a proposed specimen at 16 CSS px regular, text on background measures **10.96:1** and action text on background measures **6.12:1**. Both meet the 4.5:1 threshold for normal-size text. Default text directly on an action-colored fill measures **1.79:1** and fails. These calculations cover those three pairs only. They do not establish contrast for an uninspected component, state or print proof. WCAG 2.2 SC 1.4.3 also provides a 3:1 large-text threshold and exceptions including logotypes. [W3C criterion and exceptions](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html)

Before release, inspect the actual web specimens at both sizes, including a long action, an empty state, a missing logo and interaction states. Obtain the print asset and proof from the print owner. No desktop render, phone render or press proof was inspected for the supplied brand. No photography, icon style, new palette or substitute logo is established by the inventory.
