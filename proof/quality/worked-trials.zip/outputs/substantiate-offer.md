# City archive offer

**Buyer copy**

Send us your complete floor plans. Within ten business days of receiving them, we’ll deliver a draft shelf map for your archive. The scope covers the draft map and excludes physical relocation and reshelving.

**Internal claim decisions**

| Candidate claim | Decision | Source, scope and condition | Evidence or decision needed to change status |
|---|---|---|---|
| Deliver a draft shelf map | Use in the buyer offer | S1 commits to a “shelf-map draft” for the city archive. The deliverable is a draft. | Recheck with the scope owner if deliverable or buyer changes. |
| Within ten business days | Use with its starting condition | S1 specifies “within ten business days after receipt of complete floor plans.” The buyer supplies those plans; the clock begins on receipt of the complete set. | An earlier start, calendar-day promise or final-map deadline requires an amended commitment. |
| “Move your archive” | Withhold | S1 expressly excludes physical relocation and reshelving. | Delivery owner would need to approve a revised scope and resources for that work. |
| Complete the move “in ten days” | Withhold | S1’s deadline covers the draft map only and is expressed in business days. | A move commitment with a defined start, authorized duration and covered tasks. |
| “Without losing a book” | Withhold | No approved guarantee, loss-prevention measurement, or contractual terms. P2 examined missing reference labels, a different outcome. | An explicitly approved guarantee with eligibility, terms and remedy; any claim about historical loss also needs inventory reconciliation evidence. |
| Pilot result | Internal only | P2 recorded one missing reference label at each of two sites. Pilot notes are restricted; no evidence here of books lost, losses prevented or move performance. | Evidence owner must authorize buyer use of exact, scoped pilot wording. |
| Price or additional guarantee | Withhold | No approved price or guarantee supplied. | Commercial owner must approve price and terms; service owner must separately authorize any guarantee. |

The source locators are S1 (committed scope and exclusions) and P2 (two-site internal pilot). Named approvers and source dates were not supplied. The buyer copy relies only on the stated scope commitment.
