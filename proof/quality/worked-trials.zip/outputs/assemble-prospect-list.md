# Ferry operators and operations contacts | November 2

**Research handoff:** Bright Ferry qualifies and lists Pia Song as director of operations. Her personal address is blank. Wale Lines needs an ownership check. Harbor Nine is a current customer.

| Account ID | Company | Domain evidence | Active routes | Independent? | Evidence | Checked against file | Disposition |
|---|---|---|---:|---|---|---|---|
| F01 | Bright Ferry | bright.example appears in its general address | 6 | Yes | D1/D2 operator-directory extracts, Bright Ferry row | Nov 2 | Eligible on supplied rules |
| F02 | Wale Lines | — | 4 | Unknown | D1/D2, Wale Lines row | Nov 2 | Hold for ownership |
| F03 | Harbor Nine | — | 5 | Yes | D1/D2, Harbor Nine row and C1 customer entry | Nov 2 | Exclude as current customer |

| Account ID | Local person ID | Name | Role | Personal email | Role and address evidence | Checked against file | Freshness |
|---|---|---|---|---|---|---|---|
| F01 | P01 | Pia Song | Director of operations | | Bright Ferry staff page S1 names Pia. No personal address supplied. | Nov 2 | Listed by the employer in this file. S1's underlying update date is unknown, and May's T1 names a different director. Reconfirm before outreach. |

**Exceptions and channel checks**

- F01 / Eli Rose — May's third-party listing T1 is the only evidence. Keep Eli out of the working contact list. Reconcile the two names against dated employer evidence before assuming either an exclusive role or a departure.
- F01 / general mailbox — `info@bright.example` is an organization address in the supplied Bright Ferry extract. Keep it off Pia's personal record. Deliverability, contact permission and person-level suppression status are unverified. No open-deal or fuller suppression export was supplied.
- F02 — obtain an ownership record identifying the controlling operator. F03 — C1 settles the exclusion. Neither account has a contact in the handoff.

**Rebuild and counts.** Use only the Nov 2 file (year unspecified). Within the operator directory extracts D1/D2, match the exact company names to the named C1 customer, then apply independent ownership and 3–8 active routes inclusive. Look up the director of operations only for eligible accounts. The source file gives no finer directory-row attribution or dates. F01–F03 and P01 are handoff IDs. Three distinct companies yield one eligible, one held and one excluded. One employer-listed contact joins the sole eligible account, zero have a verified personal address, and one additional contact claim is held. Independent verification of current employment remains outstanding.
