On the local reporting dates March 1–3, 2026, March.csv recorded 12 orders, up 12 from 0 orders on February 1–3 in Feb.csv, so percentage change is undefined.

```json
{
  "current_start": "2026-03-01",
  "current_end": "2026-03-03",
  "prior_start": "2026-02-01",
  "prior_end": "2026-02-03",
  "current_total": 12,
  "prior_total": 0,
  "change_pct": null
}
```
