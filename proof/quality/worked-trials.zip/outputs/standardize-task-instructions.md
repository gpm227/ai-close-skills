# Museum return check · candidate SOP 1

**Callable instruction**

> Perform the museum return check for each incoming crate independently. Accept the crate reference, observed crate seal, and its return ticket with the ticket seal if present. Check that the ticket belongs to the crate, then compare the seals as recorded. If the ticket is missing or the seals differ, keep the crate unopened in receiving and record the reason. If the evidence is unreadable, incomplete or contradictory, keep the crate unopened in receiving and refer the unresolved check to the registrar. Only when the ticket is present and both seals match does the return clerk sign the receipt. Record one result per crate. Do not represent a signature as complete until the clerk actually signs.

The check starts when the crate arrives and ends with a signed receipt or a documented hold in receiving. The registrar supplies the rules and resolves ambiguous evidence. The return clerk signs. A clerk using this SOP can carry out the physical task; a system operating on submitted observations can instruct the clerk to sign and record the result once confirmed.

| Record field | Content |
|---|---|
| crate_ref | Reference used to identify the incoming crate |
| ticket_ref, crate_seal, ticket_seal | Observed values, with unknowns explicitly blank |
| disposition | SIGN RECEIPT, SIGNED, or HOLD UNOPENED IN RECEIVING |
| reason | Ticket and seals verified, missing ticket, seal mismatch, or specified unresolved evidence |
| receipt_ref or hold evidence | Signed receipt reference if available; otherwise the receiving hold entry or clerk action pending |

**Rule sources.** Ticket per crate, seal comparison, hold on missing ticket or mismatch, and clerk signature on match are registrar instructions. The crate, ticket, seal values and person on duty vary. Color and the employee name in the training example carry no decision authority. The proposed default for an unreadable seal is to hold pending registrar review because the positive match cannot yet be verified; the registrar should approve that exception route before adopting the SOP. No opening or restocking step is authorized by the return check.

**Invocation**

> Run the museum return check on crate M-116 in receiving. Its crate seal reads Q-37. The return ticket assigned to M-116 is RT-88 and its seal reads Q-37. There is no signed receipt yet. Return the decision record for the clerk on duty.

**Acceptance fixtures and verification**

Each check below was desk-applied to the candidate instruction, without moving a crate or signing a receipt. The expected disposition was fixed from the registrar’s rules before comparison. The actor and color vary in the first two fixtures; neither changes a seal decision.

| Case | Fixture input | Expected | Desk result under SOP 1 | Verdict |
|---|---|---|---|---|
| Normal | Blue M-116, clerk Noel, crate Q-37, ticket RT-88 for M-116, ticket seal Q-37, unsigned | Clerk signs | M-116 · RT-88 · Q-37/Q-37 · SIGN RECEIPT · verified match · signature pending | Pass |
| Unseen | Green M-117, clerk Dara, crate J-4, ticket RT-89 for M-117, ticket seal J-4, unsigned | Clerk signs | M-117 · RT-89 · J-4/J-4 · SIGN RECEIPT · verified match · signature pending | Pass |
| Missing ticket | M-118, crate Q-38, no ticket | Hold unopened in receiving | M-118 · blank · Q-38/blank · HOLD UNOPENED IN RECEIVING · missing ticket · log hold | Pass |
| Mismatch | M-119, crate Q-39, ticket RT-91 for M-119, ticket seal Q-93 | Hold unopened in receiving | M-119 · RT-91 · Q-39/Q-93 · HOLD UNOPENED IN RECEIVING · seal mismatch · log hold | Pass |
| Unreadable seal | M-120, unreadable crate seal, ticket RT-92 for M-120, ticket seal Q-40 | Hold for registrar determination under proposed default | M-120 · RT-92 · blank/Q-40 · HOLD UNOPENED IN RECEIVING · unreadable seal · refer to registrar | Consistent with proposed default; owner confirmation pending |

Verification covers instruction interpretation. Independent clerk execution and registrar adoption remain unverified.
