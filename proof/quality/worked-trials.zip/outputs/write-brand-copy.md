# About

Old Spur makes writable bin tags for shared workshop tool storage. Each tag pairs a tool name with its storage bay number.

### Directory entry

Old Spur pairs tool names and bay numbers on writable bin tags.

### Editor's source note

| Placement | Words / maximum | Claims and publication basis |
|---|---:|---|
| About, for workshop managers | 22 / 42 | P1 supplies the company name, writable bin tags, shared workshop use and tool-name/storage-bay pairing. |
| Directory entry, for workshop managers | 12 / 12 | P1 supplies the same company, tag and pairing. “Bay numbers” shortens “storage bay numbers” for this placement. |

Counts use whitespace-delimited words. P2's whiteboard add-on remains in private beta. Both public placements exclude it. Neither placement claims priority, zero loss or barcode functionality. No comparison or outcome is necessary to describe the offer.
