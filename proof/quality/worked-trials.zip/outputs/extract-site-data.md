# Ridge directory capture

[stores.csv](extract-site-data/stores.csv) · [page-status.csv](extract-site-data/page-status.csv)

```csv
"store_id","name","hours","email","source_url","capture_date","processed_date"
17,"Cedar","09–17","","https://ridge.example/shops/cedar","","2026-11-23"
23,"Elm","","elm@example.test","https://ridge.example/shops/elm","","2026-11-23"
```

One row per published store ID. The evidence is the supplied saved inventory; its capture date was unspecified. November 23, 2026 is the processing date. Each detail URL and store ID locate the observation. The captured strings are preserved, including Cedar’s hours.

| URL in the saved inventory | Status | Result |
|---|---|---|
| https://ridge.example/directory | Read | Directory index; four candidate links |
| https://ridge.example/shops/cedar | Read | Cedar, ID 17 |
| https://ridge.example/branches/cedar-old | Read, redirect | Repeats the Cedar target; no second record |
| https://ridge.example/shops/fern | Failed | HTTP 503; identity and fields unverified |
| https://ridge.example/shops/elm | Read | Elm, ID 23 |

**Coverage.** Including the index, 5 URLs = 4 read (including the redirect) + 1 failed + 0 pending. Among the 4 candidate links, 3 resolve to store observations = 2 retained stores + 1 repeated Cedar target; the failed link yielded no observation. Only 2 canonical detail pages supplied independent record data. No observed field conflicts. Coverage is partial for the supplied candidates because Fern was unavailable.

Of the 2 retained rows, one lacks email (Cedar) and one lacks hours (Elm). Neither lacks a name, store ID or source URL; both lack a capture date. Blank business fields mean unpublished in the inspected detail. The footer press address belongs to the site and was excluded from both store records. No spreadsheet escaping changed a supplied value.
