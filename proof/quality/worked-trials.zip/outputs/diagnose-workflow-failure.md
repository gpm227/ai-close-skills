# April 9–10 inventory replay plan

The April 9 ledger receipts confirm that X:11 and Y:12 applied once. The checkpoint save timed out; the April 10 retry re-read those rows. X reused effective idempotency and was skipped. Y received a regenerated external ID on retry, so the ledger applied the same logical adjustment a second time. Z:13’s post timed out. Its destination state is unknown.

The checkpoint timeout is the first observed batch-level disruption. The first observed divergence that produced a duplicate adjustment is Y’s changed external ID, compared with X’s successful skip on the same retry. The logs establish neither the reason the checkpoint timed out nor which code path regenerated Y’s ID.

| Source work ID and adjustment | Expected ledger effect | Downstream evidence | Recovery disposition |
|---|---|---|---|
| X:11 | One applied adjustment | AX on Apr 9; Apr 10 skipped | Confirmed applied once. Preserve AX, skip X. No replay or reversal. |
| Y:12 | One applied adjustment | AY on Apr 9, AZ on Apr 10 | Confirmed duplicate. Preserve AY and AZ for audit; suppress all Y reposts. Verify both amounts and source link, then present AZ to the supervisor for authorization of a compensating entry. |
| Z:13 | One applied adjustment | Timeout; no local receipt | Hold Z. Search the destination ledger by the original source work ID Z, including its posting attempts and relevant time window. Reconcile the adjustment details with the source. |

**Bounded sequence for the incident operator**

1. Preserve the April 9 and 10 traces, checkpoint record and read-only ledger results. Keep the affected batch out of automatic replay while the operator reconciles these three work IDs. No full-batch restart.
2. Do nothing to X. For Y, the supervisor must authorize an offset to AZ before an operator posts one. Preserve historical entries, use a stable compensation key linked to AZ and record the offset receipt. If authorization is pending, leave Y in the duplicate register.
3. For Z, one matching applied entry means retain its receipt and skip. Multiple matches mean stop, identify duplicates and refer them for supervisor review. If an authoritative lookup after the ledger’s settlement window confirms absence and the original post cannot still commit, retry just Z once with a stable key bound to the source adjustment. This is the single-case replay. Read back the destination before proceeding. If lookup coverage, settlement, amount or identity remains uncertain, keep Z quarantined. An empty preliminary search cannot authorize a repost.
4. Stop on any unexpected additional receipt, mismatched amount, changing external ID or ambiguous timeout. Post-check by work ID: X has one effective adjustment (AX); Y has one net adjustment after any authorized correction (AY + AZ + offset to AZ); Z has one effective matching adjustment when resolved. Never expect the duplicate to disappear from the raw ledger. Expected new inventory posts: X 0, Y 0, Z 0 or 1; compensation entries 0 or 1 subject to authorization. Unresolved items stay open.

**Prevention.** The integration owner should trace the deployed ID-construction branch for X and Y, persist or deterministically derive a stable idempotency key per logical adjustment, and retain downstream receipts independently of the file checkpoint. Test by losing a checkpoint acknowledgement, then replaying identical source rows on the candidate version. Verify that all original receipts remain unique before the owner resumes the affected route. This document records a plan only.
