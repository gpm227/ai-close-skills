# Ren | Branch librarian | 15-minute introductory call

**Open (0–1 min):** “Ren, you mentioned moving the map drawers and wanting to understand labeling. What would you like a label to help someone do?”

**First check (1–4 min):** “Would a temporary label be useful for this move, or are you just exploring options?” If useful, ask how someone currently identifies a drawer before and after the move. Follow a concrete example with “Who needs to read that, and what could they confuse it with?” If exploring, ask what Ren hopes to learn from seeing a label.

**Try one sample (4–10 min):** If Ren agrees, show the one sample label. Ask, “Looking at this, what would you keep or change for your drawers?” If it does not fit the workflow, ask what it misses and record Ren's words. Facilities owns the floor plan. Ren's message establishes interest in labeling only. Budget, purchase date and purchasing authority are unknown.

| When the conversation turns | Say this and follow the answer |
|---|---|
| Facilities joins | “Ren said facilities owns the floor plan. Which location references should match between a drawer label and your plan?” Let facilities describe the plan and Ren describe what library staff need to read. |
| Interested (10–15 min) | “Would it help if I showed the sample to the colleague you choose on a short follow-up? If so, who should arrange it and what day works?” Read back the agreed action, owner and date, or leave it open. |
| Wrong person | “Who owns drawer labeling at the branch? If you'd like to introduce us, I'll leave that with you.” End if Ren declines. |
| No project yet / bad timing | “Understood. Would you prefer to leave it here, or is there a point when you'd like me to check back?” If no time is offered, close without scheduling. |
| No | “Understood. Thanks for telling me, Ren. I'll leave it there.” End the call. If Ren requests no contact, stop and route the request to the suppression owner as pending confirmation. |
| Asked about onsite labor or delivery | “I can show the sample today. I'd need to check with our operations team before saying whether onsite work is available or giving a delivery time.” The rep owns verification. Confirm whether Ren wants an answer. |
| Silence / little context | “We can look at the one sample, or finish here. Which would you prefer?” |

**Blank post-call log**

| Disposition | Buyer's exact words | Open question(s) | Agreed next action | Owner | Date / time |
|---|---|---|---|---|---|
| | | | | | |
