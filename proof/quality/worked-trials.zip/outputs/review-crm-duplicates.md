# CRM contact duplicate review | Read-only proposal

One of three pairs supports a merge proposal. Two records need consent and identity review. Two other records identify distinct people.

| Pair | Identity and field evidence from export | Disposition | Proposed survivor / retirement |
|---|---|---|---|
| 71 / 72 | Ana Dael and A. Dael share ana@north.example. Initial and address suggest a match. Record 71 (updated 9/2) has DNC=true and open ticket T4. Record 72 (11/5) has DNC=false and no ticket. | **Review.** Treat the shared address as suppressed while the consent owner verifies identity, contact-preference history and scope. The later record update does not establish later consent. Preserve T4 linked to 71 pending reconciliation by support. | None proposed. Keep both IDs. |
| 80 / 81 | Timo Crane and Teo Crane share office@pearl.example and an employer. Their staff profiles and direct lines distinguish them. | **Keep apart.** Retain both people, lines and staff associations. The office address is a shared channel. | Neither retires. |
| 90 / 91 | Both Edie Ross rows share a direct email and ERP person ID P-005. Their names match. | **Merge proposal.** Strong corroboration across name, email and external person key. Apply the stated lowest-ID rule to survivorship and field provenance separately. | Retain **90**, provisionally retire **91**. No write authorized. |

**Field and relationship map for the sole proposal**

| Field or link | Before on 90 | Before on 91 | Proposed on 90 | Source and basis |
|---|---|---|---|---|
| Mobile | Current value unspecified | Newer corrected mobile, digits unspecified | Copy the exact corrected value from 91 after capturing both originals. | The export identifies a field-specific correction on 91. No digits can be reconstructed from the brief. |
| Billing reference | B5 | Unspecified | Preserve B5 and its billing relationship. | 90 carries B5. Verify the billing linkage on the survivor. |
| Name / direct email / ERP person ID | Edie Ross / direct email / P-005 | Identical values per export | Preserve survivor's actual display name, direct email and P-005. | Source reports agreement; direct email string is omitted in this extract. |
| CRM identifiers / dependent links | ID 90 | ID 91 | Retain 90 as canonical, map original 91 → 90, reconcile every dependent link using full snapshots. | Default survivor rule. No complete relationship inventory is supplied. |

**Reconciliation.** Six unique records, three candidate pairs. The single proposal has one unique survivor (90) and one unique retiring ID (91). Four other IDs remain separate (71, 72, 80, 81). Five canonical records would remain if the sole proposal were applied; all six currently remain.

**Recovery boundary.** This extract preserves the stated identifiers, dates, flags, named references and proposed mapping. It cannot establish CRM undo support, restore lost activities or association history, recover unspecified phone values or demonstrate what else links to 90/91. Before any authorized merge, capture immutable full raw rows with exact previous values, field and preference history, activities, deals, tickets, billing/external links with keys and owners, and the field-by-field survivor/retired crosswalk. Verify the CRM's actual undo or tested restore procedure and reconcile link counts after application. Recovery from this export alone is unverified.
