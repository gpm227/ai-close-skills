# What buyers said about using paper

Mae prints a shift list because people share one tablet. Liv described putting a paper sign by the door during school visits. Both used paper in a specific situation. Only Mae attributed the choice to shared access. Neither buyer expressed purchase intent.

| Observation | Buyer-session support | Distinct account support | Evidence | Counterevidence or limit |
|---|---:|---|---|---|
| Paper used during a particular workflow | 2 of 2 buyer-bearing sessions (T1, T2) | Unknown / unknown. No account IDs supplied. | T1.1, Mae: “I print the shift list because the tablet is shared.” T2.1, Liv: “We put a paper sign by the door during school visits.” | A shift list and a door sign serve different jobs. A shared cause is unestablished. |
| Device access explains printing the shift list | 1 of 2 (T1) | Unknown / unknown | Mae volunteered the reason in T1.1 and clarified in T1.3: “No, there’s only one tablet.” | T2 offers no explanation for posting the sign. T3 has no buyer observation. |
| Software speed explains Mae's behavior | 0 of 2 | Unknown / unknown | T1.2–3: the seller asked “So the software is too slow?” Mae explicitly rejected that explanation. | Mae's answer contradicts this explanation for her workflow. Liv never discussed speed. |

**Interpretation.** For Mae, printing may help colleagues see the list when someone else has the tablet. For Liv, the audience and purpose of the door sign are open questions. There are two named buyers and two sessions containing buyer testimony among three total sessions. Without employer mappings, neither a distinct-account denominator nor an account-level frequency can be calculated.

**Ask next**

- Mae: “Walk me through the last shift when someone needed the list while the tablet was in use. Who used the printout, and what happened?” Follow up on impact only if she describes one.
- Liv: “What did the sign say on the last school visit, who needed to see it, and how did you know it had done its job?”
- If either buyer identifies a problem: “Who else deals with that, and who decides whether to change the process?” No buyer identified a new location, purchasing owner or expansion project.

**Evidence ledger.** T1.1 and T2.1 are buyer-originated. T1.2 is seller prompting, and T1.3 is the buyer's rejection/clarification. T3.1, seller-only note “Probably another shortage of tablets.”, is conjecture and contributes zero buyer support. No quote clearance for publication is supplied.
