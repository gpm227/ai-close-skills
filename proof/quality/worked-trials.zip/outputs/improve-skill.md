# Private change proposal · order readiness

The candidate’s **“or”** allows a single positive field to mark an order ready. It contradicts the owner’s version 1.2 rule requiring affirmative packing **and** dispatch confirmations in the same order record. O17’s recorded “ready” is an observed failure against that rule. The producing runtime version and run ID are unknown; a compatible error in the candidate text does not establish which release produced O17.

**Frozen criterion R1.** A ready decision requires packing=yes and dispatch=yes in the order’s own record. A blank or negative value in either field fails that condition. Preserve O17 as the regression, O19 as the dispatch-only held-out check, and O18 as a previously valid input under the old rule. No actual O18 or O19 outputs were supplied.

**One instruction replacement, pending owner approval**

```diff
-Mark ready once packing or dispatch is confirmed.
+Mark ready only when both packing and dispatch are confirmed in the order’s record.
```

| Case / role | Input | Owner criterion R1 | Original observed output | Old candidate, static reading | Proposed instruction, static reading |
|---|---|---|---|---|---|
| O17 · regression | packing=yes, dispatch=blank | Withhold ready | ready · fails R1 | ready · fails | Withhold ready · matches |
| O18 · preserved case | packing=yes, dispatch=yes | Mark ready | Unavailable | ready · matches | ready · matches |
| O19 · different single-confirmation case | packing=no, dispatch=yes | Withhold ready | Unavailable | ready · fails | Withhold ready · matches |

**Evidence and limits.** The supplied text, owner rule and recorded O17 result establish a specification mismatch and a real incorrect output. The static comparison verifies the proposed wording’s logical agreement on all three inputs. It supplies no runtime reproduction, frequency estimate, regression pass, independent held-out execution, deployed-version attribution, or business outcome.

**Owner decision.** Keep this as a private candidate; a possible release identifier is 1.2.1 if version 1.2 is confirmed as the applicable skill release. To qualify it, obtain O17’s run ID, served instruction version and execution settings; reproduce the original on that version, then run the candidate in isolation and retain actual outputs on O17 and O18. A second reviewer should run O19 without its answer key. Only the owner can approve a release. After an approved release, verify the served version in a fresh session and check the three dispositions again. No runtime or publication action occurred.
