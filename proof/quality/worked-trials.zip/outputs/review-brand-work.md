# Revised web block

Plan your crate labels.

Match each label to its crate before packing.

**Request a label proof**

### Release review

| Placement and rule | Before | Evidence and smallest correction | After |
|---|---|---|---|
| Heading and body, R1: name the object | Pass | “crate labels,” “each label” and “its crate” identify the objects. Preserve both lines verbatim. | Pass |
| Button, R2: describe next action | Fail | “Get labels now” implies immediate delivery of labels. D1 describes a request that staff review before emailing a proof. Replace only the button with “Request a label proof.” | Pass against supplied D1 |
| Heading, R3: Georgia | Unknown | Pasted plain text cannot establish the rendered typeface. Inspect the live or staged heading and its rendered font on each published variant. | Unknown |

**Original release decision: hold** for the inaccurate CTA. **Revised text: ready. Revised web placement: needs verification** of the Georgia heading in the rendered page. D1 was described in the brief. No click or live page inspection occurred. “Discover” is an editor preference with no approved rule behind it and introduces no correction.
