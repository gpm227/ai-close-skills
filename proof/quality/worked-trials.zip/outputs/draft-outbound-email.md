# Mara Noll | Draft email sequence

**Touch 1 · proposed day 0 · first email**

**Subject:** Shelf labels for inventory

Hi Mara,

Pinwheel Archive's 3 November bulletin mentions the 14 November reading-room closure for inventory. If anything needs to move temporarily, I can email you a sample of the paper labels we offer for shelf moves.

Would you like a sample?

**Purpose and single ask:** Give the facilities lead a way to assess the sample if shelf moves become relevant. Ask for a yes/no reply allowing the rep to email it.

**Touch 2 · proposed four business days later · only while there is no reply and the inventory reference remains timely**

**Subject:** Paper label sample

Hi Mara,

You can review the label by email without arranging a call. If you'd like the sample for a future temporary shelf move, just say the word. I'll leave it here.

**Purpose and single ask:** Clarify how the sample can be reviewed and close the sequence. An affirmative reply is the only requested action.

**Source and operating notes.** The owner brief identifies Mara Noll as facilities lead at Pinwheel Archive and authorizes sending a sample by email on request. The archive's 3 November bulletin documents a 14 November closure for inventory. It does not document a shelf move. Neither touch assumes one. No further follow-up is proposed because there is no additional evidence or resource to offer. Stop on any reply, decline, opt-out or hard bounce. If the inventory date has passed, the neutral wording in touch 1 remains factual, but do not schedule touch 2 on that event's timing. Both messages are drafts.
