# Bookstore returns worksheet | Draft for owner review

**Decision.** Which first line prompts more independent bookstores to request the worksheet within seven days? The owner has forbidden sending. All copy, assignments and timing below are proposals.

**Why a manager might act.** Managers already forward email to one another, so a worksheet they can share when returns change hands is the best-grounded hypothesis. Saving preparation time is the runner-up, based on the worksheet offer. A third possibility is checking the store’s existing process for omissions. Buyer confirmation is unavailable.

| Email element | A · Handoff | B · Preparation time |
|---|---|---|
| Proposed first line | I thought this might help when returns work changes hands. | I thought this might save time when you prepare returns. |
| Subject and next line | “Returns worksheet” / “Would you like me to send our returns worksheet?” | Identical to A |
| Delivery | One email to one designated manager per store, from the same named rep and mailbox, at the same local time in each daily wave. No follow-up. | Identical to A |

**Assignment.** The list has 60 candidate stores and 240 contact records before deduplication. Deduplicate stores and contacts across territories, remove registered customer accounts, apply explicit opt-outs at their recorded scope, and drop stores with no eligible manager. The eligible count is pending. Log losses at each step and the final count by territory. Choose the eligible store manager first, breaking ties by stable contact ID. Within each territory, randomize stores 1:1, balancing odd remainders across territories. Freeze the store ID, all linked contacts, territory, arm, recipient and wave before any touch. All four contacts inherit the store’s arm. If forwarding links span stores, resolve those links before assignment so linked stores cannot receive opposing versions.

**Rep sequence if later authorized.** Before each wave, the rep rechecks suppression and reserves capacity for replies already due. Cap new stores at the remaining number of store conversations the named rep can handle that day, balanced across arms. Zero confirmed capacity means zero entries. At 10 a.m. local time, send the assigned version once. Any human reply exits outreach for the store. The rep classifies it and fulfills requests within one business day. Apply opt-outs immediately across arms. Stop new entries for suppression failures, cross-arm exposure or a reply backlog and document affected stores separately.

**Readout.** Count a store once if any colleague there sends a human reply explicitly requesting or accepting the worksheet within 168 hours of the first send attempt. Retain unsent assignments using their scheduled time. A forward, referral, automatic reply or held call alone does not qualify. A referred colleague’s qualifying reply at the same store counts. Log late replies and referrals to other stores separately. Keep bounces and unsent stores in the primary denominator. Track delivery, replies and held calls separately. Ignore opens.

| Illustrative counts only | A | B |
|---|---:|---:|
| Positive stores / all assigned eligible stores **(primary)** | 3/30 = 10.0% | 4/30 = 13.3% |
| Positive stores / stores with ≥1 delivered email | 3/20 = 15.0% | 4/30 = 13.3% |

Use verified delivery records for the second row and mark it unavailable if delivery is unknown. Read once the last store’s 168 hours expire. Report actual counts and B minus A in percentage points with a 95% interval that accounts for the assignment design. With at most about 30 stores per arm and no agreed minimum worthwhile lift, treat the result as exploratory. Name no winner. If the test stops early or forwarding crosses arms, disclose the interruption or exposure at readout.
