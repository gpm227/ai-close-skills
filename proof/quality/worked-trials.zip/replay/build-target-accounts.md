# Oregon music-school account decisions

**Sales can pursue 0 accounts today.** Of the four accounts in the supplied directory, three are excluded and one is on hold. The approved size band includes 4 through 12 operating teaching sites in Oregon.

| Source ID | Account | Oregon teaching sites | Decision | Reason |
|---|---|---:|---|---|
| M1, CRM C1 | Fiddlepost | 4 | Exclude | The four schools meet the size rule and Fiddlepost is independently owned. CRM C1 identifies it as a current customer. Its six rented concert venues add no teaching sites. |
| M2 | Red Staff | 3 | Exclude | The planned fourth school opens next March according to M2. Reassess the count once the opening is confirmed. |
| M3 | True Alto | 7 | Exclude | A national chain owns True Alto. |
| M4 | Fir Bow | 8 | Hold | Ownership is unknown. Obtain dated evidence of independent ownership, then clear the account against the current-customer register before release. |

The directory supplies account-level Oregon school counts without as-of dates or individual site records. Site-level duplicate checks are unavailable. C1 confirms Fiddlepost's status and gives no customer status for the other names.

[All account decisions](build-target-accounts/account-decisions.csv) · [Eligible accounts](build-target-accounts/eligible-accounts.csv)

The ledger contains each of M1–M4 once. The eligible CSV has a header and zero account rows. Confidence in the classifications from the supplied evidence is high.
