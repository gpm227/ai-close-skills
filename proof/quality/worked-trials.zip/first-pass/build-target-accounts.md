# Oregon music schools | Account decisions

**Sales can pursue 0 accounts today.** The rule counts 4–12 currently operating Oregon **teaching sites**, inclusive, for an independently owned school. Exclude current customers. A future school and rented concert venues contribute zero current teaching sites.

| Account / source | Observed teaching sites in extract | Current Oregon teaching sites | Ownership / exclusion evidence | Disposition and next action |
|---|---:|---:|---|---|
| M1 Fiddlepost | 4 | 4 | Independently owned per M1. C1 names Fiddlepost as a current customer. | **Excluded.** Customer suppression overrides size and ownership fit. The six rented concert venues do not count. |
| M2 Red Staff | 3 | 3 | M2 says the fourth school opens next March. | **Excluded.** Three currently operating Oregon teaching sites is below four, irrespective of ownership. Reassess only after evidence of an actual opening. |
| M3 True Alto | 7 | 7 | M3 identifies a national chain as owner. | **Excluded.** Fails independent ownership. |
| M4 Fir Bow | 8 | 8 | M4 omits ownership. C1 identifies Fiddlepost as a customer. | **Needs evidence.** Verify whether Fir Bow is independently controlled, using an ownership record tied to this school. Recheck customer status before release if the roster has changed. |

**Reconciliation.** Four distinct accounts, three excluded, one held, zero eligible. The [eligible-only CSV](build-target-accounts/eligible.csv) has a header and zero data rows. The [decision ledger](build-target-accounts/decisions.csv) retains each source ID once with its actual deciding rule.

**Source and count limits.** The directory supplies exact current Oregon counts but no address-level roster, non-Oregon counts or evidence dates. The normalized site rows expand the published totals using local counting keys, so `roster_complete=yes` refers to the stated Oregon count only. There are zero duplicate count keys. Physical site duplicates cannot be audited against unnamed sites. The runner checks the inclusive size range; ownership and customer findings were checked against M1–M4 and C1 and restored in the decision ledger. The runner's generic hold for M4 refers here to its missing ownership field. [Source crosswalk](build-target-accounts/source-crosswalk.csv).
