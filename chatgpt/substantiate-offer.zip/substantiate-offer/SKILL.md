---
name: substantiate-offer
description: "Builds an offer from what you can actually deliver and prove, and flags every claim that isn't backed. Use for writing an offer, packaging a service, a value proposition, or \"what should we promise.\""
---

# Substantiate an offer

Use when sales or marketing needs an offer the delivery team can fulfill. Gather the intended buyer, scope, limits, prerequisites, capacity, pricing basis, historical outcomes and who approved each source for this use. A buyer outcome, a seller-controlled deliverable and a contractual commitment need different evidence.

## Decide what belongs in the offer

- Break the proposed sentence into atomic claims. For each, record exact supporting language, source location/date, owner, eligible customer, timing start, exclusions and permission to publish. Mark it usable as written, usable within named limits, or held.
- Confirm that a delivery commitment is authorized for this scope. Measured elapsed time across past jobs is evidence of history; the owner must establish any forward deadline or guarantee. State what the customer supplies and when the clock starts. When price or turnaround has no source, omit the figure or name the actual quoting process supplied.
- Match outcomes to the observed population and metric. Three customers sharing a result can justify a scoped observation if the evidence and usage rights support it. “Most clients” needs an appropriate denominator. A pilot without a comparison cannot establish a causal uplift.
- When sources conflict, surface both exact conditions and narrow to an uncontested statement only where that is supportable. Do not resolve crossed pricing or terms by picking the more attractive one.

Return buyer-ready offer copy with fulfillment conditions next to the promise. Follow with an internal claim table and withheld list. For each held claim, name the smallest missing decision or record that would change its status. Do not expose private evidence in public copy. Recheck price, capacity and rights if the owner changes scope or channel.

[Practice separating a delivery deadline from a customer outcome](examples/practice.md).

**Using this skill for the first time?** On the public GitHub page, open the repository name above this file. In its README, **All 37 Skills** takes you to the individual downloads and **deployment guide** covers team setup. In a downloaded ZIP, open `SETUP.md` for the installation and source links. In a company copy, start at `company/DEPLOY.md`. For native installation, follow [OpenAI’s upload instructions](https://help.openai.com/en/articles/20001066-skills-in-chatgpt).
