# Install this skill in ChatGPT

Open Plugins → Skills → Create → Upload from your computer and select the original ZIP. After the upload scan, start a fresh chat. [Workspace permissions and upload instructions](https://help.openai.com/en/articles/20001066-skills-in-chatgpt)

## Try it on your work

Daily totals with dates, the metric you care about and your cutoff date.

> Compare this month through my cutoff with the same elapsed dates last month. Show both totals, their change and any dates that could change the conclusion.

To try the skill with sample material, open [examples/practice.md](examples/practice.md).

[Find this download in the catalog](https://github.com/gpm227/ai-close-skills/blob/main/CATALOG.md) · [Read the deployment guide](https://github.com/gpm227/ai-close-skills/blob/main/company/DEPLOY.md)
