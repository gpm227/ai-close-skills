# Use this skill in ChatGPT

In a workspace with Skills enabled, open **Plugins → Skills → Create → Upload from your computer**. Select the original ZIP. After the scan, confirm the skill is installed and start a fresh chat. Use the request below with your own material. You can unzip a copy to read the bundled examples.

For a manual trial when Skills is unavailable, attach `SKILL.md` and the inputs or supporting files it calls for in a fresh chat. A task that uses a script needs a chat that can run code. [Workspace permissions and upload instructions](https://help.openai.com/en/articles/20001066-skills-in-chatgpt)

## Try it on your work

The kinds of companies and roles you want, the intended use and a directory, account list or public research scope.

> Build linked company and contact tables. Keep qualified companies in the list even when a current contact cannot be verified.

To try the skill with sample material, open [examples/practice.md](examples/practice.md).

For other downloads or team setup, open the [public edition notes](https://github.com/gpm227/ai-close-skills/pull/5). Its description links to the catalog and deployment guide (`company/DEPLOY.md`).
