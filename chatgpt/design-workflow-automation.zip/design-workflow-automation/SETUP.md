# Install this skill in ChatGPT

Open Plugins → Skills → Create → Upload from your computer and select the original ZIP. After the upload scan, start a fresh chat. [Workspace permissions and upload instructions](https://help.openai.com/en/articles/20001066-skills-in-chatgpt)

## Try it on your work

A description or screenshot of the handoff you want to automate. Add a sample record if available.

> Design this workflow so the team can build and test it. Map the fields and show what should happen on a retry, duplicate or partial failure.

To try the skill with sample material, open [examples/practice.md](examples/practice.md).

[Find this download in the catalog](https://github.com/gpm227/ai-close-skills/blob/main/CATALOG.md) · [Read the deployment guide](https://github.com/gpm227/ai-close-skills/blob/main/company/DEPLOY.md)
