# Use this skill in ChatGPT

In a workspace with Skills enabled, open **Plugins → Skills → Create → Upload from your computer**. Select the original ZIP. After the scan, confirm the skill is installed and start a fresh chat. Use the request below with your own material. You can unzip a copy to read the bundled examples.

For a manual trial when Skills is unavailable, attach `SKILL.md` and the inputs or supporting files it calls for in a fresh chat. A task that uses a script needs a chat that can run code. [Workspace permissions and upload instructions](https://help.openai.com/en/articles/20001066-skills-in-chatgpt)

## Try it on your work

A recipient, a relevant public or supplied fact, your offer and the relationship or connection status.

> Draft the LinkedIn message appropriate to our current relationship. Show when each follow-up would make sense and when to stop.

To try the skill with sample material, open [examples/practice.md](examples/practice.md).

[Browse the skills in this edition](https://github.com/gpm227/ai-close-skills/blob/4637172068a9be34d32764b05c07a5dd33c586df/CATALOG.md) · [Read the deployment guide](https://github.com/gpm227/ai-close-skills/blob/4637172068a9be34d32764b05c07a5dd33c586df/company/DEPLOY.md)
