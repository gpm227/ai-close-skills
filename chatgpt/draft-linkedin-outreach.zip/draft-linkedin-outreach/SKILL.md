---
name: draft-linkedin-outreach
description: "Writes a LinkedIn connection note and two short follow-ups to one person, based on something real about them. Use for LinkedIn outreach, connection requests, LinkedIn DMs, or social selling messages."
---

# Draft LinkedIn outreach

Use for a private invitation or direct message to one professional. A public post needs the author's evidence and voice instead. Read the supplied profile excerpt or post, source and date, relationship state, reason to connect and the desired outcome. Without a specific, attributable detail, ask for a profile excerpt or use an explicitly supplied shared context. Never infer personal acquaintance or attendance.

## Decide which messages belong

If a rep supplies an account brief, use the signal marked usable for this angle. Carry the account ID, signal ID, source and check date into the rep's notes outside the message. Verify whose action the source describes and why this recipient's responsibilities connect to it. On a hold, expired evidence or conflicting update, say which fact needs checking and withhold the signal-based draft. Another independently verified reason may support a separate draft when requested. If the rep already drafted against an older status, identify which line to retire.

| Relationship now | Return |
| --- | --- |
| No connection or pending invite | For a new invitation, one note under 200 characters including spaces, with no sales pitch. For a pending invite, leave the invitation alone. Label later messages conditional on acceptance. |
| Already connected, no active conversation | Skip the invitation. Draft an opening DM and at most one follow-up if it adds a different useful fact or resource. |
| Replied, declined or opted out | End the unanswered sequence. Address a reply only when the thread and a response are requested. Record the stop for a decline or opt-out. |

Write as the named sender. Distinguish the recipient's own statement from their employer's news or a conference listing. A speaker listing establishes the appearance listed, not the content of the talk or attendance by the sender. Use one concrete reason per message and at most one ask. Use the connection-note character budget as the skill's editorial default and honor any smaller limit provided by the user.

Return paste-ready drafts, stage and condition for each, and separate notes mapping every personalized detail to its source. Count the final invitation including punctuation and spaces. If two follow-ups would repeat the same pitch, explain which one you omitted. Drafting completes the job.

[Practice on a speaker listing, with a pending-invite variation](examples/practice.md).

## Try it on your work

A recipient, a relevant public or supplied fact, your offer and the relationship or connection status.

> Draft the LinkedIn message appropriate to our current relationship. Show when each follow-up would make sense and when to stop.

**Get the download.** On GitHub, keep the branch or commit shown for this file. Open `CATALOG.md` in the repository’s file tree and download `draft-linkedin-outreach.zip`. If someone sent you the ZIP, open its `SETUP.md` for the first run. For a company release, use `company/DEPLOY.md` in your private repository.
