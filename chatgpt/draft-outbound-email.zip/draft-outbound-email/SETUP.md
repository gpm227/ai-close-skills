# Install this skill in ChatGPT

Open Plugins → Skills → Create → Upload from your computer and select the original ZIP. After the upload scan, start a fresh chat. [Workspace permissions and upload instructions](https://help.openai.com/en/articles/20001066-skills-in-chatgpt)

## Try it on your work

An offer, the recipient’s role or responsibility and the next step you want. Add a relevant trigger if available.

> Draft the first email and useful follow-ups. Ground the reason for writing in the material I supplied and give the reader one clear action.

To try the skill with sample material, open [examples/practice.md](examples/practice.md).

[Find this download in the catalog](https://github.com/gpm227/ai-close-skills/blob/main/CATALOG.md) · [Read the deployment guide](https://github.com/gpm227/ai-close-skills/blob/main/company/DEPLOY.md)
