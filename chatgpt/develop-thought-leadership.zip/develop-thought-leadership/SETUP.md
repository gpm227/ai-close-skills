# Install this skill in ChatGPT

Open Plugins → Skills → Create → Upload from your computer and select the original ZIP. After the upload scan, start a fresh chat. [Workspace permissions and upload instructions](https://help.openai.com/en/articles/20001066-skills-in-chatgpt)

## Try it on your work

An expert observation, the audience, and any examples, data or counterexamples supporting the argument.

> Build a publishable argument around this observation. Give the strongest counterargument, the limits of the evidence and what the reader could do differently.

To try the skill with sample material, open [examples/practice.md](examples/practice.md).

[Find this download in the catalog](https://github.com/gpm227/ai-close-skills/blob/main/CATALOG.md) · [Read the deployment guide](https://github.com/gpm227/ai-close-skills/blob/main/company/DEPLOY.md)
