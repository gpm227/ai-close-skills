# Use this skill in ChatGPT

In a workspace with Skills enabled, open **Plugins → Skills → Create → Upload from your computer**. Select the original ZIP. After the scan, confirm the skill is installed and start a fresh chat. Use the request below with your own material. You can unzip a copy to read the bundled examples.

For a manual trial when Skills is unavailable, attach `SKILL.md` and the inputs or supporting files it calls for in a fresh chat. A task that uses a script needs a chat that can run code. [Workspace permissions and upload instructions](https://help.openai.com/en/articles/20001066-skills-in-chatgpt)

## Try it on your work

A CRM export with record IDs and available identity fields, such as company, email or domain.

> Which records appear to be the same entity? Show the evidence, which fields to keep and which pairs need someone to check before merging.

To try the skill with sample material, open [examples/practice.md](examples/practice.md).

For other downloads or team setup, open the [public edition notes](https://github.com/gpm227/ai-close-skills/pull/5). Its description links to the catalog and deployment guide (`company/DEPLOY.md`).
