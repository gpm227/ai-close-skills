# Install this skill in ChatGPT

Open Plugins → Skills → Create → Upload from your computer and select the original ZIP. After the upload scan, start a fresh chat. [Workspace permissions and upload instructions](https://help.openai.com/en/articles/20001066-skills-in-chatgpt)

## Try it on your work

A deck, website, capture or approved piece of writing, plus the intended reader.

> Build an editable brand guide from these materials. Show the voice and visual rules we can use today, their sources and the decisions the owner still needs to make.

To try the skill with sample material, open [examples/brief.md](examples/brief.md).

[Find this download in the catalog](https://github.com/gpm227/ai-close-skills/blob/main/CATALOG.md) · [Read the deployment guide](https://github.com/gpm227/ai-close-skills/blob/main/company/DEPLOY.md)
